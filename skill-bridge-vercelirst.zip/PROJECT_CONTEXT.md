# Skill Bridge — project context for future Codex work

## Product brief

Build a focused career-planning prototype for students and early-career learners. Learners create a browser-local profile, choose career aspirations, report skills/projects/coursework, pick a company and position, compare their profile with role requirements, and receive a practical learning roadmap.

## Current prototype behavior

1. **Cover entry:** the welcome card says “Start your journey.” `Create a workspace` opens the three-step profile setup, and a saved profile is previewed when present. Saving setup changes the one browser-local profile. `Try the demo` seeds a sample profile on a fresh browser. There is no account or password authentication. Name, career paths, skill selections, one of five original CSS-animated avatars, study availability and learning progress are stored in `localStorage` under `skillBridge.profile.v1`.
2. **Role research:** Company and position fields are sent to Adzuna (if server credentials are present). A source URL is retained as a local note only. Role descriptions pasted by the learner are analyzed as provided text. LinkedIn is deliberately not fetched or scraped.
3. **Skill mapping:** `skill_engine.py` compares job titles/snippets or a labeled sample with pasted role requirements and self-reported skills. Optional Gemini analysis adds role-specific skills and tasks when the learner checks the opt-in box and a server key exists. The same opt-in lets Gemini rank available YouTube candidate videos; it may only select known video IDs, so thumbnails and playback still come from YouTube.
4. **Multi-role leaderboard:** the Skills page switches among saved target titles and ranks skills by frequency across listings. The skill-name buttons open a plain-language explanation and example, explain what the listing count means, show whether the learner listed the skill in their profile, and offer a role-map exercise with evidence to save. Counts describe this listing set, not a complete labor-market standard. `/api/leaderboard` is a lightweight endpoint separate from video/course discovery. Results are cached in this browser; `data/skills_leaderboard.json` provides ten labelled offline sample snapshots for static hosting or API outages. `generate_demo_data.py` rebuilds them from the built-in sample listings.
5. **GitHub refresh:** `refresh_leaderboards.py` can refresh configured titles using Adzuna, and `.github/workflows/refresh-leaderboards.yml` runs daily or manually and commits the JSON snapshot. It requires Adzuna repository secrets and a `JOB_TITLES` Actions variable; it only aggregates skill counts and does not store raw postings or scrape LinkedIn.
6. **Progression:** Up to four missing skills become paced milestones with skill-specific exercises (for example, a Power BI dashboard, a data-cleaning notebook, or an A/B test analysis), proof to save, and study links. Completion is stored locally and survives refreshes. Completing all four shows a completed state and a brief reduced-motion-aware celebration in the progress widget.
7. **Learning:** Public GitHub repository searches include stars and license metadata when available. Optional Gemini guidance ranks verified YouTube videos/playlists per target skill; the YouTube API supplies direct IDs and thumbnails when configured, with curated demo videos as fallback. Roadmap cards link to direct watch/playlist pages where a match exists and to Coursera/Udemy/NPTEL course searches.
8. **Role-specific courses and data provenance:** `data/course_catalog.json` supplies five topic searches for each of ten built-in job roles. The provider links search Coursera, Udemy, or NPTEL; they are not claims about verified individual courses. Gemini may tailor query terms after explicit opt-in. Role-map source details name role listings or sample data, skills, courses, videos, GitHub, profile, and AI provider status. Original SVG artwork for course searches, plus CSS cover art and avatars, is local and uses no external decorative image assets. Video thumbnail links open their YouTube destination directly; video details retain an in-app preview action.
9. **The Guide:** `/api/assistant` returns career-learning help or one schema-constrained UI action. The browser executes only its fixed allowlist (switch/add role, filter/sort/layout, highlight, export, refresh); it cannot run code. Chat history is stored locally in this browser (last 30 messages). Messages and compact career context are sent to Gemini when a learner sends a chat and a Gemini key is configured; UI discloses this.
10. **Professional responsive UI and appearance:** Skill Bridge uses a blue-led workspace, responsive bottom navigation on phones, and visible product states. Users can choose Light, Dark, or device-based theme from Profile → Appearance; quick theme toggles are available on welcome, setup, and dashboard screens. The preference is saved in browser local storage and the first paint follows it without a flash. The original small wizard icon is local at `guide-wizard.svg`. `UI_REFERENCES.md` records 20 live products reviewed for layout patterns; no third-party UI assets or source code are copied.
11. **Hosting:** Static frontend at project root and Python functions at `/api/analyze`, `/api/leaderboard`, `/api/assistant`; deploy through Vercel CLI or Git integration so the Python runtime is built (a static-only Vercel Drop deployment will not run these functions). `.python-version` pins Vercel functions to Python 3.12. GitHub Pages can serve the leaderboard snapshot only; local start is `python server.py`.
12. **Dashboard interactions:** Home has an Edit profile shortcut and the sidebar/profile controls also open the editor. Learners can update their name, stage, avatar, career paths, skills, notes, location, and study schedule; updates save locally and refresh role analysis. A JPG, PNG, or WebP profile photo can be resized in the browser and saved locally; users can remove it or return to an illustrated avatar. Weekly study targets accept whole hours from 1 to 80. A mutually exclusive “None yet” skill choice represents an empty skill list in saved profile data. The Workspace breadcrumb opens the career learning map. Overview stats are keyboard/click accessible. Role skills opens the complete mapped list, Skills matched lists strengths based on self-reported profile entries, Study time opens a weekly browser-local start/stop timer, and Career goals opens role-specific software suggestions with map links. Study sessions and profile data stay local unless sent in an opted-in AI analysis or Guide message.
13. **Workspace command search:** The top bar’s “Search workspace” control and `Ctrl+K` open a keyboard-operable command palette. It filters local navigation actions (Home, career map, role research, learning resources, profile, and The Guide) without sending any user data.
14. **Role tools:** `data/role_tools.json` lists tools for common roles. Gemini can tailor a role tool list in the same structured role-guidance request used for skills and exercises. The UI shows whether each recommendation came from Gemini or the local guide.
15. **Data portability:** Profile settings can download a JSON backup of the local profile, study sessions, role maps, and Guide chat. The backup stays on the learner’s device unless they choose to share it.
16. **Request validation:** Local and Vercel API handlers reject non-object JSON payloads with clear client errors. YouTube API credentials are sent in a request header rather than a URL query string.

## Important product boundaries

- Demo entry is intentionally not a real account system. Before multi-user production, implement real authentication, account storage, consent, retention/deletion controls, API abuse protection, and secure secret storage.
- Never scrape LinkedIn. Official API access is limited/approval-based. Keep the user-provided role text and reference URL as the safe fallback unless a proper approved integration is in place.
- Gemini receives profile and role notes only when the checkbox opt-in is present in the analysis request. Its output is advisory; course provider URLs are constructed by the app from search terms rather than trusted as model-generated direct URLs.
- Home multi-path analysis uses up to three concurrent requests and optional Gemini guidance. Google quota is shared at project level; when a request is limited or fails, that role records an error and can be retried. Gemini ranks existing YouTube candidates only; it does not generate video URLs or thumbnails.
- `gemini_client.py` applies a two-call semaphore per Python process, bounded timeouts, structured JSON, no automatic retry on quota failure, and local fallbacks. Skill and tool advice share one generation request. The Guide receives a whitelisted compact summary of profile skills, mapped strengths/gaps, tools, roadmap, and tracked weekly hours only when a learner sends a chat; post-action acknowledgements are local and do not trigger a second Gemini call. Public-candidate video rankings are cached for ten minutes.
- Gemini uses the configured model (default `gemini-3.5-flash-lite`); provider quotas apply. A local `.env` is loaded by `server.py` but must never be packaged; `env.template` is safe to include. Provider data policies vary, so keep learner consent explicit.
- Do not describe the current matcher as a trained AI model. It is transparent keyword matching with frequency weighting and a heuristic readiness percentage.
- Keep sample data visibly labeled. Never present a fallback sample as a live company requirement.
- Keep third-party secrets server-side; do not commit `.env` files or output secrets into logs.
- Course searches are links, not a claim that the app has access to, evaluated, or endorses the paid course catalogs.
- This is not a trained AI model. Gemini is an optional external API, called only after opt-in; local keyword rules keep the demo functional without it.

## Files to know

- `index.html` contains the landing/demo screen, profile wizard, dashboard, map, research and learning views.
- `app.js` handles navigation, local persistence, form interactions, API requests, video previews and rendering.
- `styles.css` contains the visual system and responsive layout. Component patterns are custom and were informed by a free MIT dashboard reference; no third-party template code is shipped.
- `skill_engine.py` owns API/source work, skill taxonomy and recommendations.
- `ai_client.py` and `gemini_client.py` centralize optional server-side Gemini calls.
- `data/role_tools.json` defines role-level software suggestions.
- `data/course_catalog.json` contains five role-focused provider-search topics for each built-in career path.
- `server.py` makes the app usable locally with Python only.
- `api/analyze.py` adapts the same engine to Vercel Python Functions.
- `api/leaderboard.py` returns per-title skill frequencies; `api/assistant.py` exposes bounded AI assistant actions.
- `assistant_engine.py` calls the configured provider server-side and validates all UI action names and arguments.
- `guide-wizard.svg` is the local original mascot; Guide chat history is stored in browser localStorage.
- `UI_REFERENCES.md` lists 20 design research sites reviewed for this update.
- `data/skills_leaderboard.json` contains offline sample boards; regenerate with `python generate_demo_data.py`.
- `refresh_leaderboards.py` and `.github/workflows/refresh-leaderboards.yml` refresh snapshots from Adzuna on a schedule or manual run.
- `build-zip.ps1` creates a clean Vercel handoff ZIP and excludes secrets/caches.
- `README.md` is the end-user run/deploy guide.

## Good next increments

- Add more job families, skill aliases, and location-aware role vocabularies; keep unknown roles visibly in sample mode.
- Add an approved job-board/API integration, cache/rate limits, and bounded provider requests before wider public use.
- Add evidence levels or short diagnostics so learner-entered skills have more precision.
- Add optional storage and real authentication only after a privacy/retention model is defined.
- Verify UI accessibility, mobile layouts, Python API behavior, provider outages, Vercel ZIP deployment and keyless/Gemini modes.

## Handoff maintenance

When Codex changes the product, update this file if behavior or architecture changes, update `README.md` for user-facing run/deploy changes, and rebuild the handoff ZIP using `build-zip.ps1` from clean source files (exclude secrets, caches, deployment state and generated dependency folders). Make the handoff ZIP match the source folder at the end of each requested update.
