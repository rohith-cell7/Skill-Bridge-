param(
  [string]$OutputPath = (Join-Path $PSScriptRoot 'skill-bridge-vercel.zip')
)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$destination = [System.IO.Path]::GetFullPath($OutputPath)
$destinationDirectory = [System.IO.Path]::GetDirectoryName($destination)
if (-not (Test-Path -LiteralPath $destinationDirectory)) {
  New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
}

$temporaryZip = Join-Path $projectRoot '.skill-bridge-package-temp.zip'
if (Test-Path -LiteralPath $temporaryZip) { Remove-Item -LiteralPath $temporaryZip -Force }

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::Open($temporaryZip, [System.IO.Compression.ZipArchiveMode]::Create)
try {
  $files = Get-ChildItem -LiteralPath $projectRoot -Recurse -File -Force | Where-Object {
    $relative = $_.FullName.Substring($projectRoot.Length).TrimStart('\', '/')
    $relative -notmatch '(^|[\\/])(__pycache__|\.vercel|node_modules|\.git|\.vscode|\.idea|\.antigravity|\.gemini|\.cache|\.impeccable)([\\/]|$)' -and
    $relative -notmatch '(^|[\\/])\.env([^\\/]*$)' -and
    $_.Name -notin @('package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml') -and
    $_.Name -notmatch '^(credentials?|secrets?)([._-].*)?$' -and
    $_.Extension -notin @('.pyc', '.pyo', '.pem', '.p12', '.pfx', '.key') -and
    $_.Name -notin @('.DS_Store', 'Thumbs.db') -and
    $_.Name -notlike '*.zip'
  }
  foreach ($file in $files) {
    $entryName = $file.FullName.Substring($projectRoot.Length).TrimStart('\', '/').Replace('\', '/')
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, $entryName, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
  }
}
finally {
  $archive.Dispose()
}

Copy-Item -LiteralPath $temporaryZip -Destination $destination -Force
Remove-Item -LiteralPath $temporaryZip -Force
Write-Output "Created $destination"
