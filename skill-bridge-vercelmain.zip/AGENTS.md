# Instructions for Codex working on Skill Bridge

- Read `PROJECT_CONTEXT.md` before changing behavior and `README.md` before changing setup or deployment.
- Preserve the new project name **Skill Bridge** across product copy, page title, and documentation.
- Treat this as a Vercel-ready product demo. Keep the UI responsive, viewer-friendly, keyboard-operable, and clear about demo/sample data.
- Preserve the local-only demo profile behavior unless replacing it with an explicitly implemented, secure account system. Do not label demo access as secure authentication.
- Keep LinkedIn scraping disabled. A URL may be retained as a local reference; analyze learner-pasted role text or an authorized source/API.
- Keep API credentials in server environment variables. Never place credentials in client code, committed config, logs, or the handoff ZIP.
- Keep provider failures graceful and demo-mode labels visible. Validate externally supplied URLs and render user/provider content as text.
- Before finishing a user-requested update, sync `README.md` and `PROJECT_CONTEXT.md` when relevant and rebuild `outputs/skill-bridge-vercel.zip` from the project source. Exclude `__pycache__`, `.env*`, `.vercel`, credentials, editor state, and dependency caches.
- Use only dependencies that are necessary; verify their source and license before adding them.
