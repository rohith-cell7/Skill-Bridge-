# Open Skill Bridge in Antigravity

This is a normal source project; no Antigravity extension or dependency install is required.

1. Extract the ZIP to a folder you can edit. In Antigravity, choose **Open Folder** and select the extracted project root—the folder containing `index.html`, `app.js`, `styles.css`, `api`, and `vercel.json`.
2. Open Antigravity’s terminal with that folder as the current directory.
3. For local preview, run `python server.py` and open <http://localhost:8080>. The app uses Python’s standard library; no `pip install` step is needed.
4. To make local API integrations work, copy `env.template` to `.env`, fill only the provider keys you choose, and restart the server. Never put API keys in frontend files or share `.env`.
5. To deploy with live APIs, follow **Deploy the ZIP with working APIs** in `README.md` and use the Vercel CLI or Git integration. A static-only Vercel Drop deployment does not execute these Python endpoints.

The app can still be previewed without keys; sample job data is labeled and learning recommendations have fallbacks.
