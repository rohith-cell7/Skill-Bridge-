# Attribution

The dashboard layout takes inspiration from common sidebar/card patterns in [TailAdmin Free Tailwind Dashboard Template](https://github.com/TailAdmin/tailadmin-free-tailwind-dashboard-template), released under the MIT License. Skill Bridge's UI markup and styling are custom; no TailAdmin source code, images, or assets are included in this package.

Curated video preview links point to YouTube lessons by freeCodeCamp.org, ProgrammingKnowledge and Simplilearn. Thumbnails and video playback are served by YouTube when viewed.

The supplied Marvie Sketch UI kit was used only as a visual reference (dark navy surfaces, bright green actions, and compact cards). The Sketch archive, its assets, and its source files are not included in this project or handoff ZIP.
