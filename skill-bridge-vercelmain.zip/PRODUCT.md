# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

Students and early-career learners, and people changing careers. The confirmed audience groups are equally important. They are exploring a target role and need a practical way to understand which skills to build next.

## Product Purpose

Skill Bridge helps people compare skills they report having with the skills named in job listings or role descriptions, then turn gaps into a paced learning plan.

## Positioning

The product connects a learner's self-reported skills to role-specific skill evidence and turns the difference into concrete practice steps with resources.

## Operating Context

The first visit offers profile creation or a sample demo. Profiles and progress are stored in the current browser. Learners can choose target roles, review skill matches, research a specific role using text they provide, and follow a weekly learning plan.

## Capabilities and Constraints

- Job-listing results can be labelled sample data or use the configured Adzuna API; small listing sets are signals, not universal hiring requirements.
- Optional Gemini guidance requires an explicit opt-in for role analysis and a server-side API key. The Guide sends a compact career context when the learner sends a message.
- Course, video, and repository recommendations have provider-backed or clearly labelled fallback paths.
- Do not scrape LinkedIn. A pasted role description may be analyzed; a saved URL is only a local reference.
- The existing profile, demo, theme, onboarding, dashboard, and learning flows must remain functional during cover-page redesign.
- Keep the name **Skill Bridge** and existing product facts. Do not invent testimonials, customer counts, labor-market claims, or verified course endorsements.

## Brand Commitments

The product is named Skill Bridge. The existing Skill Bridge mark and name remain recognizable. The user has asked for a more impressive, attractive, innovative cover page with animation; this permission applies to the cover surface, not the rest of the application.

## Evidence on Hand

- Existing runnable product and demo in `index.html`, `app.js`, and `styles.css`.
- Role skill sample snapshots in `data/skills_leaderboard.json` and a seeded Data Analyst demo profile.
- Original local mark at `public/icon.svg` and original Guide illustration at `guide-wizard.svg`.
- No testimonials or independently verified outcome metrics are supplied.

## Product Principles

- Make the next learning step understandable.
- Ground career advice in visible source context and label sample data honestly.
- Keep learners in control of optional sharing with external providers.
- Turn skill gaps into small pieces of practice and evidence.

## Accessibility & Inclusion

Keep the web experience responsive and keyboard-operable. Respect reduced-motion preferences, provide usable focus states, and do not make animation necessary to understand or use the cover.
