# Skill Bridge

Skill Bridge is a Vercel-ready career-planning prototype. Learners switch between job-title skill leaderboards, compare their profile with a specific company role, and follow a paced plan with GitHub, course, and video resources. The responsive workspace has saved Light, Dark, and device-based themes plus a keyboard-friendly command search (`Ctrl+K`).

## Try it on your computer

Requires Python 3.10+ (no packages to install).

```powershell
cd "C:\path\to\skill-bridge"
python server.py
```

Open <http://localhost:8080>. Select **Create a workspace** to open profile setup, or **Try the demo** on a new browser to preview sample data. Profile data is saved in this browser's `localStorage`; no real sign-in or password is used. Creating and saving a new profile replaces the profile currently saved in that browser. The analysis API receives profile text only when you run an analysis and does not store it.

If port 8080 is occupied, run `$env:PORT = "8081"; python server.py` and open <http://localhost:8081>.

### Open the project in Antigravity

Extract the ZIP, then choose **Open Folder** in Antigravity and select the extracted project root (the folder containing `index.html` and `vercel.json`). Open its terminal and run `python server.py` to preview at <http://localhost:8080>. No packages are required. See [`ANTIGRAVITY.md`](ANTIGRAVITY.md) for API-key and deploy notes.

## Connect APIs and deploy to Vercel

The app works without API keys using clearly labelled sample data and curated learning links. Connect only the providers you want. Keys belong in server environment settings; never paste them into `app.js`, commit them, or include them in a ZIP. All four integrations are optional.

### 1. Deploy the ZIP with working APIs

This ZIP includes Python serverless functions (`/api/analyze`, `/api/leaderboard`, `/api/assistant`) and a Vercel build step that stages the frontend and its assets into `dist/`. Deploy through the Vercel CLI or a connected Git repository so both the static page and Python functions are built. **Vercel Drop can publish the static page, but a static-only Drop deployment does not run this project's Python API functions.** See Vercel’s [Python Functions guide](https://vercel.com/docs/functions/runtimes/python) and [Vercel Drop guide](https://vercel.com/kb/vercel-drop).

1. Extract `skill-bridge-vercel.zip`. Check that `index.html`, `api`, `vercel.json`, and `.python-version` are directly inside the extracted folder—not one level deeper.
2. Install the [Vercel CLI](https://vercel.com/docs/cli) if needed: `npm install --global vercel`.
3. Open PowerShell in that folder. Run `vercel login`, then `vercel`; follow the prompts to select your account and create/link a project. This creates a preview deployment.
4. On the preview URL, open `/api/analyze` directly. It should return JSON containing `"status":"ready"`. Then build a role map in the app; it should work with labelled sample data before any provider keys are configured.
5. In the Vercel project dashboard, open **Settings → Environment Variables**. Add the provider variables described below, choosing **Production** and (if wanted) **Preview**.
6. Back in the extracted folder, run `vercel --prod`. Environment-variable changes only apply to a new deployment, so run this again after adding or changing keys. The project pins the Vercel Python runtime to 3.12; Vercel currently lists Python 3.12 as its default supported version.

Alternatively, push the extracted folder to a Git repository and import the repository into Vercel; its root `api/*.py` files are then deployed as Python functions.

For a fresh ZIP from PowerShell, run `./build-zip.ps1 -OutputPath "C:\path\to\skill-bridge-vercel.zip"`.

### 2. Optional providers

**YouTube lessons (`YOUTUBE_API_KEY`)**

1. In [Google Cloud Console](https://console.cloud.google.com/), create or select a project.
2. Open **APIs & Services → Library**, find **YouTube Data API v3**, and enable it for that project.
3. Open **APIs & Services → Credentials → Create credentials → API key**.
4. Edit the key’s **API restrictions** and restrict it to **YouTube Data API v3**. This app sends YouTube requests from its server function, so do not choose an HTTP-referrer restriction intended for browser JavaScript. If your hosting setup provides a stable server IP, you can optionally allowlist it; otherwise use the API restriction and keep calls on the server.
5. Add the key to Vercel as `YOUTUBE_API_KEY`, then redeploy. The Learning page will search current lessons and show real video thumbnails; when the key is absent or the provider is unavailable, it falls back to labelled curated/search results. This app sends the key in an HTTP header rather than the URL. Review Google’s [YouTube API setup](https://developers.google.com/youtube/v3/getting-started) and [API-key security guidance](https://docs.cloud.google.com/docs/authentication/api-keys-best-practices); API quota limits apply.

**Optional Gemini guidance**

1. Create a Gemini API key in [Google AI Studio](https://aistudio.google.com/app/apikey) and set `GEMINI_API_KEY` on the server. `GEMINI_MODEL` is optional and defaults to `gemini-3.5-flash-lite`.
2. For local development, copy `env.template` to `.env` and enter the key on your machine. Never place a key in `app.js`, HTML, or a public ZIP. For Vercel, add it in the project’s server environment settings and redeploy.
3. Learners must select the consent checkbox before profile and role notes are sent for analysis. The Guide sends its compact career context only when a learner sends a message. Leave Gemini disconnected to use local matching and planning.
4. Check Google’s [Gemini setup guide](https://ai.google.dev/gemini-api/docs/get-started) and current usage terms before enabling it.

**Live job listings (`ADZUNA_APP_ID` and `ADZUNA_APP_KEY`)**

1. Register for API credentials in the [Adzuna Developer portal](https://developer.adzuna.com/overview).
2. Add the app ID as `ADZUNA_APP_ID` and app key as `ADZUNA_APP_KEY` in Vercel. Set both together, then redeploy.
3. Company/role research will use live Adzuna job listings when available. If either value is missing or the provider is unavailable, the app clearly labels its sample data. The app does not scrape LinkedIn. See [Adzuna’s API overview](https://developer.adzuna.com/overview).

**GitHub learning projects (`GITHUB_TOKEN`, optional)**

1. No token is needed for basic public-repository search. Add one only if you need the higher authenticated GitHub API rate limit.
2. On GitHub, open **Settings → Developer settings → Fine-grained personal access tokens → Generate new token**. Use an expiry, and grant no write/admin access. The app only searches public repositories; keep permissions at the minimum GitHub allows for public read access.
3. Add it to Vercel as `GITHUB_TOKEN`, then redeploy. Keep the token private. See GitHub’s [fine-grained token instructions](https://docs.github.com/en/enterprise-cloud%40latest/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens) and [REST API rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api).

### Test the integrations

Open the deployed site and build a role map. Confirm live listings are attributed to Adzuna, video cards show YouTube results when configured, and GitHub cards link to public projects. To test optional AI, configure `GEMINI_API_KEY`, tick the opt-in checkbox before analyzing, or send a message in The Guide. If the key is missing, local guidance remains available.

### Local API setup

1. In the project folder, copy `env.template` to `.env` once, then open `.env` in a text editor and fill only the provider values you use. For example, `YOUTUBE_API_KEY=...`.
2. Start or restart the local server with `python server.py`; it loads `.env` on startup.
3. **Keep `.env` on your computer.** It is git-ignored and excluded from the Vercel ZIP; do not send it in chat, commit it, or put it in frontend code.

### Optional GitHub leaderboard refresh

1. Push the project to a GitHub repository; this ZIP does not connect or push to one for you.
2. In **Settings → Secrets and variables → Actions**, add `ADZUNA_APP_ID` and `ADZUNA_APP_KEY` as repository secrets. Add `JOB_TITLES` as a comma-separated repository variable (for example `Data Analyst,Data Scientist,UX Designer`).
3. Enable Actions. `.github/workflows/refresh-leaderboards.yml` refreshes titles daily or on demand, and commits only `data/skills_leaderboard.json`. A manual run can refresh one title. The workflow uses Adzuna’s API and does not scrape LinkedIn.
4. GitHub Pages can serve the static title snapshots. The roadmap and Gemini assistant still need the Python API host, such as the included Vercel deployment.

The project stages its frontend into `dist/` during the Vercel build and includes Python Vercel Functions at `/api/analyze`, `/api/leaderboard`, and `/api/assistant`. Vercel currently documents its Python runtime as Beta. See [Vercel Python Functions](https://vercel.com/docs/functions/runtimes/python) and [Vercel’s CLI deployment guide](https://vercel.com/docs/projects/deploy-from-cli). Vercel account limits and third-party API quotas may apply.

The app can be tried locally without paid services or API keys. Hosting and optional provider APIs have their own free-tier limits, which can change; check each provider's current pricing before enabling them.

## What the prototype actually does

- **Demo access:** explore a seeded student profile, or create a browser-local profile.
- **Learner setup:** choose multiple dream roles, current skills, stage, location, and study hours.
- **Dashboard details:** use **Edit profile** on Home or the profile controls to update your name, career paths, skills, location, study schedule, and avatar. Set any whole-hour weekly target from 1 to 80, choose **None yet** when you have no listed skills, or upload a JPG, PNG, or WebP professional photo (up to 5 MB). Photos are resized and stored only in this browser. The **Workspace** breadcrumb opens the career learning map. Click (or keyboard-focus and press Enter on) Role skills, Skills matched, Study time, and Career goals. Role-skill details show every mapped skill; matched skills are covered based on your self-reported profile. Career goals lists role-specific tools, and the weekly study panel stores start/stop study sessions in this browser.
- **Profile avatars:** choose one of five original animated CSS avatars in setup or profile settings. The artwork is drawn with CSS; no AI-generated, stock, or downloaded avatar images are bundled.
- **All-path mapping:** Home can analyze every saved career path, with at most three role requests in flight. Optional Gemini guidance uses a server-side key; quotas are shared across the Google project and may limit larger batches.
- **Skills leaderboard:** choose a job title to see how often each skill appears in its listings and whether it matches your profile. Select a skill name to see a plain-language explanation and example, what the listing count means, whether you listed it in your profile, and a suggested exercise with evidence to save. Counts describe the available listing set, not the whole job market. Filter, reorder, change layout, highlight a skill, and download CSV/JSON. Results are saved in this browser; ten built-in title snapshots also work on a static host or offline after the page files are available. Sample data is labelled.
- **Role/company research:** open **Skills → Research a company and position**, optionally paste requirements or keep a public role URL as a note. Adzuna is queried for role/company listings when credentials are configured. LinkedIn page scraping is not included; use user-provided job text or a LinkedIn API product for which your app has explicit approval and access.
- **Skill match:** local keyword matching compares learner-provided skills with job snippets and pasted requirements. With a Gemini key and explicit consent, Gemini adds role-specific skills, exercises, and search queries. The local matcher remains available when AI is off or unavailable.
- **Adaptive roadmap:** up to four milestones include a practical task, proof to save, and links to GitHub, Coursera, Udemy, NPTEL, and YouTube. Estimate duration adapts to study hours; completion is saved in the browser.
- **Learning library:** each built-in career path has five role-specific course-topic searches across Coursera, Udemy, and NPTEL. Cards use locally authored topic illustrations and open provider searches, not verified course listings. Each role map requests up to eight distinct skill lessons. Video thumbnails link directly to their YouTube video, playlist, or search; the card text still opens the in-app preview for videos. With `YOUTUBE_API_KEY`, actual video/playlist results and their thumbnails are shown; uncovered skills get a role-specific YouTube search card, never a made-up video. Without the key, matching curated demos are used where available and uncovered skills still get honest search cards. Optional AI ranking only selects known video/playlist IDs. GitHub searches cover the top four skill gaps, with up to two relevant API results per skill, star counts, and license labels when available; search links remain when the API has no match.
- **The Guide:** open the bottom-right Guide chat for career and learning help or supported page actions (switch/add a role, filter/sort, change layout, highlight skills, refresh listings, or export). Gemini can use the current role's matched/gap skills, tool suggestions, roadmap, profile skills, and weekly tracked time; this short context is sent only when you send a chat. The assistant selects from a fixed action list and cannot run code. The latest 30 chat messages stay in this browser. A server-side `GEMINI_API_KEY` is optional; local actions and fallbacks remain available without it.
- **Workspace shortcuts:** use the top-bar search or `Ctrl+K` to find Home, the career map, role research, learning resources, profile editing, or The Guide without hunting through navigation.
- **Appearance:** switch between Light and Dark from the welcome, setup, or dashboard bar; choose Light, Dark, or Use device setting in Profile → Appearance. The preference is saved in this browser. A locally bundled original wizard icon labels The Guide; see `UI_REFERENCES.md` for 20 reviewed design references.
- **Data backup:** Profile settings → **Download my data** saves a JSON copy of the local profile, study sessions, role maps, and Guide chat to your device. It is not uploaded by this action.
- **Recommendation sources:** open “Where did this information come from?” on the career map. Each skill has a short reason and source label; live listings and AI provider documentation link to their providers, while sample-mode sources are explicitly labeled. Long explanations and task details stay on one line until **More** is selected. Career goals include a distinct role summary and concise tool explanations.
- **Local server and Vercel:** the same engine runs via `python server.py` locally and `/api/analyze`, `/api/leaderboard`, and `/api/assistant` on Vercel.

## API keys

Set these only in your local shell or Vercel environment variables. Do not put them in `app.js` or commit them.

| Variable | Purpose | Required |
| --- | --- | --- |
| `ADZUNA_APP_ID` / `ADZUNA_APP_KEY` | Search live job listings | Optional; demo data works without them |
| `GEMINI_API_KEY` | Optional role guidance, video selection, and The Guide | Optional; analysis requires checkbox consent, assistant calls happen only after the learner sends a message |
| `GEMINI_MODEL` | Override Gemini model id | Optional; defaults to `gemini-3.5-flash-lite` |
| `YOUTUBE_API_KEY` | Live YouTube video recommendations | Optional; curated demo videos work without it |
| `GITHUB_TOKEN` | Raise GitHub public API quota | Optional |

## Source boundaries and privacy

- LinkedIn pages and profiles are **not scraped**. LinkedIn's [crawling terms](https://www.linkedin.com/legal/crawling-terms) prohibit automated crawling without express permission. Learners can paste role text they have permission to use; the optional URL is stored locally as a reference and is not fetched.
- LinkedIn integrations are permission-based. LinkedIn publishes a limited API product catalogue and access depends on the product, OAuth scopes, and approval; this prototype cannot query arbitrary LinkedIn profiles or job pages. The [API terms](https://www.linkedin.com/legal/l/api-terms-of-use) and [product catalogue](https://developer.linkedin.com/product-catalog) describe those limits. Paste authorized role text or use the configured job-listings API.
- Student profile text is sent to the same-origin analysis API only when the learner requests a comparison. It is sent to the configured AI provider only after the learner opts in and a server-side key is configured. The demo API does not persist profiles or log request bodies. Job and GitHub searches use role/company or skill terms, not profile text.
- Adzuna may return short job-description snippets. Frequency in a small sample is a signal, not a complete competency standard.
- YouTube thumbnails, video embeds, and provider searches load from their providers when the learner views or clicks them.
- Udemy and Coursera results use official site search links because generally available course catalog APIs are limited/partner oriented. NPTEL uses an indexed search link. Always check availability, cost, language, and prerequisites at the provider.
- The skill match is a learning aid, not a hiring prediction, qualification, or employment decision. AI-generated skills and tasks can be wrong; review the result and follow source links.
- The app can use Google Gemini's API with a constrained JSON response. It is optional and is not a model trained by this project; local rules still work when it is off or unavailable.
- The shared server-side AI clients limit concurrent requests to two per Python process, avoids retrying quota errors, and returns to local guidance when a provider is busy. Video ranking is cached for ten minutes per identical public role/video candidate set. Skill and tool guidance are produced in one schema-constrained response; the Guide sends one model call per chat turn, including after page actions. Project quotas vary; see Google's [model list](https://ai.google.dev/gemini-api/docs/models) and [rate limits](https://ai.google.dev/gemini-api/docs/rate-limits).
- AI video recommendations select only from known YouTube video or playlist IDs; the model does not invent playback URLs or thumbnails. YouTube results are cached locally for 30 minutes per process. Free-tier use has limited quotas, and Google states free-tier prompts may be used to improve its products.

## Project structure

- `index.html`, `styles.css`, `app.js` — interface and browser-local learner workflow.
- `skill_engine.py`, `assistant_engine.py`, `ai_client.py`, `gemini_client.py`, `api/` — analysis, resources, optional Gemini integration, and Vercel endpoints.
- `data/`, `generate_demo_data.py`, `refresh_leaderboards.py` — role catalogs and sample/live leaderboard data.
- `server.py` runs locally; `build-zip.ps1` packages a clean handoff. No Python packages are required.

The custom interface was informed by common dashboard patterns; see [ATTRIBUTION.md](ATTRIBUTION.md). No external runtime packages are bundled.

For next steps, read [PROJECT_CONTEXT.md](PROJECT_CONTEXT.md) and [AGENTS.md](AGENTS.md).
