# UI references reviewed for the dark-green refresh

Reviewed 20 live sites on 25 September 2026. The prototype uses these as interaction and visual references only; it does not copy their code, assets, or branded components.

| Product area | References | Pattern carried into Skill Bridge |
| --- | --- | --- |
| Navigation, dashboard, assistant | [Linear](https://linear.app/), [Vercel](https://vercel.com/dashboard), [Raycast](https://www.raycast.com/), [GitHub](https://github.com/), [GitLab](https://gitlab.com/), [Notion](https://www.notion.so/), [Figma](https://www.figma.com/) | Stable sidebar, direct labels, restrained surfaces, clear active state, compact support chat. |
| Career maps and skill progression | [roadmap.sh](https://roadmap.sh/), [Grow with Google](https://grow.google/), [AWS Training](https://aws.amazon.com/training/learn-about/), [LinkedIn Learning](https://www.linkedin.com/learning), [freeCodeCamp](https://www.freecodecamp.org/) | Role-first paths, ordered steps, practical resources, visible progress. |
| Courses and tutorials | [Coursera](https://www.coursera.org/), [Udemy](https://www.udemy.com/), [edX](https://www.edx.org/), [Khan Academy](https://www.khanacademy.org/), [DataCamp](https://www.datacamp.com/), [Codecademy](https://www.codecademy.com/), [Pluralsight](https://www.pluralsight.com/), [YouTube](https://www.youtube.com/) | Course/video thumbnails, title-first cards, obvious source links and compact metadata. |
| Learning by building | [Google Career Certificates](https://grow.google/certificates/), [GitHub Explore](https://github.com/explore), [roadmap.sh GitHub repository](https://github.com/kamranahmedse/developer-roadmap/) | Show projects and repositories next to the skills they help practice. |

The original `guide-wizard.svg` mascot and all application UI assets are local. Resource links and optional Gemini/API calls still use their respective providers when a learner chooses them.
