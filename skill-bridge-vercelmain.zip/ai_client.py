"""Provider selection for optional server-side AI features."""
import os
import threading
from gemini_client import generate_json as generate_gemini_json

_PROVIDER_STATE = threading.local()


def configured_provider():
    if os.environ.get("GEMINI_API_KEY", "").strip():
        return "gemini"
    return None


def generate_json(prompt, schema, **options):
    """Use optional Gemini guidance, returning None for the local-rule fallback."""
    if not configured_provider():
        return None
    result = generate_gemini_json(prompt, schema, **options)
    if result is not None:
        _PROVIDER_STATE.last_successful = "gemini"
    return result


def reset_provider_state():
    _PROVIDER_STATE.last_successful = None


def last_successful_provider():
    return getattr(_PROVIDER_STATE, "last_successful", None)
