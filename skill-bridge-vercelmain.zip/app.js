const PROFILE_KEY = "skillBridge.profile.v1";
const GUIDE_CHAT_KEY = "skillBridge.guide.chat.v1";
const STUDY_KEY = "skillBridge.study.v1";
const THEME_KEY = "skillBridge.theme.v1";
const NO_SKILLS = "__none_yet__";
const state = { profile: readProfile(), selectedAvatar: readProfile()?.avatar || "sprout", analysis: null, analysisKey: "", analysisRequest: 0, analysisController: null, pendingPathAnalysis: null, pathAnalyses: readPathAnalyses(), currentView: "overview", currentRole: "", leaderboards: readLeaderboards(), offlineBoards: null, leaderboardMin: 1, leaderboardSort: "desc", leaderboardLayout: "grid", highlightedSkill: "", study: readStudy(), roleToolsCatalog: null, studyTimer: null };
const ROLES = ["Data Analyst", "Data Scientist", "Data Engineer", "Software Engineer", "UX Designer", "Product Manager", "Project Manager", "Cybersecurity Analyst", "Business Analyst", "Digital Marketer"];
const SKILLS = ["SQL", "Excel", "Python", "Statistics", "Data visualization", "Tableau", "Power BI", "Data cleaning", "Communication", "Git", "JavaScript", "HTML & CSS", "Figma", "User research", "UX design", "Agile", "Project management", "APIs", "Testing", "Security fundamentals", "Linux", "Networking", "Research", "Writing"];
const AVATARS = [{ id: "sprout", name: "Sprout" }, { id: "orbit", name: "Orbit" }, { id: "ember", name: "Ember" }, { id: "book", name: "Book" }, { id: "peak", name: "Peak" }];
const ROLE_VALUE = {
  "Data Analyst": "Turn business data into clear reports and decisions.",
  "Data Scientist": "Use statistics and machine learning to answer harder questions.",
  "Data Engineer": "Build reliable pipelines that make data ready to use.",
  "Software Engineer": "Design, build, test, and maintain useful software.",
  "UX Designer": "Make products easier to understand and use.",
  "Product Manager": "Set priorities and help teams solve the right user problem.",
  "Project Manager": "Plan delivery, coordinate people, and manage project risks.",
  "Cybersecurity Analyst": "Find security issues and help teams respond to them.",
  "Business Analyst": "Translate business needs into clear requirements and decisions.",
  "Digital Marketer": "Reach the right audience and measure campaign results.",
};

function readProfile() {
  try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || "null"); } catch { return null; }
}
function readLeaderboards() { try { return JSON.parse(localStorage.getItem("skillBridge.leaderboards.v1") || "{}"); } catch { return {}; } }
function profileSignature(profile = state.profile) { return JSON.stringify({ roles: [...(profile?.roles || [])].sort(), skills: [...(profile?.skills || [])].sort(), moreSkills: profile?.moreSkills || "", location: profile?.location || "", hoursPerWeek: profile?.hoursPerWeek || 5 }); }
function readPathAnalyses() { try { const cache = JSON.parse(localStorage.getItem("skillBridge.paths.v1") || "null"); return cache?.signature === profileSignature(readProfile()) ? cache.results || {} : {}; } catch { return {}; } }
function savePathAnalyses() { try { localStorage.setItem("skillBridge.paths.v1", JSON.stringify({ signature: profileSignature(), results: state.pathAnalyses })); } catch { toast("Could not save all career maps in browser storage."); } }
function saveProfile() {
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(state.profile)); return true; }
  catch { toast("Profile updated for this visit, but browser storage is unavailable."); return false; }
}
function q(selector, root = document) { return root.querySelector(selector); }
function qa(selector, root = document) { return [...root.querySelectorAll(selector)]; }
function el(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; }
function cleanText(value) { return String(value || "").trim(); }
function safeUrl(value) { try { const url = new URL(value); return ["https:", "http:"].includes(url.protocol) ? url.href : "#"; } catch { return "#"; } }
function setProgress(node, percent) { node.style.transform = `scaleX(${Math.max(0, Math.min(100, percent)) / 100})`; }
async function readJson(response) { try { return await response.json(); } catch { return {}; } }
function toast(message) { const node = q("#toast"); node.textContent = message; node.classList.add("show"); window.clearTimeout(toast.timer); toast.timer = window.setTimeout(() => node.classList.remove("show"), 2600); }
function readThemePreference() {
  try { const value = localStorage.getItem(THEME_KEY); return ["system", "light", "dark"].includes(value) ? value : "system"; }
  catch { return "system"; }
}
function paintThemeIcon(button, dark) {
  const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  icon.setAttribute("viewBox", "0 0 24 24"); icon.setAttribute("aria-hidden", "true");
  icon.setAttribute("fill", "none"); icon.setAttribute("stroke", "currentColor"); icon.setAttribute("stroke-width", "1.8");
  icon.setAttribute("stroke-linecap", "round"); icon.setAttribute("stroke-linejoin", "round");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", dark ? "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" : "M12 3v2m0 14v2m9-9h-2M5 12H3m15.36-6.36-1.42 1.42M7.06 16.94l-1.42 1.42m12.72 0-1.42-1.42M7.06 7.06 5.64 5.64M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z");
  icon.append(path);
  const label = el("span", "theme-toggle-label", `Switch to ${dark ? "light" : "dark"}`);
  button.replaceChildren(icon, label);
}
function applyTheme(preference = readThemePreference()) {
  const valid = ["system", "light", "dark"].includes(preference) ? preference : "system";
  const dark = valid === "dark" || (valid === "system" && window.matchMedia?.("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  document.documentElement.style.colorScheme = dark ? "dark" : "light";
  const meta = q('meta[name="theme-color"]'); if (meta) meta.content = dark ? "#101923" : "#f4f7fb";
  qa("[data-theme-toggle]").forEach((button) => {
    button.setAttribute("aria-label", `Switch to ${dark ? "light" : "dark"} mode`);
    button.setAttribute("title", `Switch to ${dark ? "light" : "dark"} mode`);
    button.setAttribute("aria-pressed", String(dark));
    paintThemeIcon(button, dark);
  });
  const select = q("#appearance-preference"); if (select && select.value !== valid) select.value = valid;
  return dark;
}
function setThemePreference(preference) {
  const valid = ["system", "light", "dark"].includes(preference) ? preference : "system";
  try { localStorage.setItem(THEME_KEY, valid); } catch { toast("Theme changed for this visit, but browser storage is unavailable."); }
  applyTheme(valid);
}
qa("[data-theme-toggle]").forEach((button) => button.addEventListener("click", () => setThemePreference(applyTheme() ? "light" : "dark")));
q("#appearance-preference").addEventListener("change", (event) => setThemePreference(event.target.value));
if (window.matchMedia) {
  const systemTheme = window.matchMedia("(prefers-color-scheme: dark)");
  const onSystemThemeChange = () => { if (readThemePreference() === "system") applyTheme("system"); };
  if (systemTheme.addEventListener) systemTheme.addEventListener("change", onSystemThemeChange);
  else systemTheme.addListener?.(onSystemThemeChange);
}
applyTheme();
function roleValue(role, data = null) {
  if (ROLE_VALUE[role]) return ROLE_VALUE[role];
  const leadSkill = data?.skills?.find((skill) => skill.status === "gap")?.name;
  return leadSkill ? `Build a practical ${leadSkill} work sample for this path.` : `Explore the skills and tools used in ${role} work.`;
}
function sourceLink(source, label = "Source", url = "") {
  const value = String(source || "");
  const safe = url ? safeUrl(url) : "#";
  if (safe === "#") return el("small", "insight-origin", `${label} · ${value || "Skill Bridge role guide"}`);
  const link = el("a", "insight-origin source-link", `${label} · ${value || "Source details"}`); link.href = safe; link.target = "_blank"; link.rel = "noopener noreferrer"; return link;
}
function addMore(container, text, className = "expandable-copy", limit = 132) {
  const value = cleanText(text); if (!value) return;
  const preview = el("p", className, value); container.append(preview);
  if (value.length <= limit) return;
  preview.classList.add("is-clamped");
  const button = el("button", "more-toggle"); button.type = "button"; button.setAttribute("aria-expanded", "false");
  const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg"); icon.setAttribute("viewBox", "0 0 20 20"); icon.setAttribute("aria-hidden", "true");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path"); path.setAttribute("d", "M4 7.5 10 13l6-5.5"); icon.append(path);
  button.append(icon, el("span", "", "More")); button.addEventListener("click", () => {
    const expanded = button.getAttribute("aria-expanded") === "true";
    button.setAttribute("aria-expanded", String(!expanded)); button.classList.toggle("is-open", !expanded); preview.classList.toggle("is-expanded", !expanded); button.querySelector("span").textContent = expanded ? "More" : "Less";
  });
  container.append(button);
}
function avatarMark(type) { const mark = el("span", `avatar-art avatar-art-${AVATARS.some((item) => item.id === type) ? type : "sprout"}`); mark.setAttribute("aria-hidden", "true"); return mark; }
function paintAvatar(node, type, photo = "") {
  if (!node) return;
  if (typeof photo === "string" && photo.length < 900000 && /^data:image\/jpeg;base64,[A-Za-z0-9+/]+=*$/.test(photo)) {
    const image = el("img", "avatar-photo"); image.src = photo; image.alt = "Uploaded profile photo";
    node.replaceChildren(image); node.setAttribute("aria-label", "Uploaded profile photo"); return;
  }
  node.replaceChildren(avatarMark(type));
  node.setAttribute("aria-label", `${AVATARS.find((item) => item.id === type)?.name || "Sprout"} avatar`);
}
function resizeProfilePhoto(file) {
  if (!file || !["image/jpeg", "image/png", "image/webp"].includes(file.type)) return Promise.reject(new Error("Choose a JPG, PNG, or WebP image."));
  if (file.size > 5 * 1024 * 1024) return Promise.reject(new Error("Choose a photo smaller than 5 MB."));
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), image = new Image();
    const release = () => URL.revokeObjectURL(url);
    image.onload = () => {
      try {
        const scale = Math.min(1, 512 / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext("2d");
        if (!context) throw new Error("This browser could not process the photo.");
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          if (!blob) { release(); reject(new Error("This photo could not be processed. Try another image.")); return; }
          const reader = new FileReader();
          reader.onload = () => { release(); resolve(String(reader.result || "")); };
          reader.onerror = () => { release(); reject(new Error("This photo could not be read. Try another image.")); };
          reader.readAsDataURL(blob);
        }, "image/jpeg", 0.82);
      } catch (error) { release(); reject(error); }
    };
    image.onerror = () => { release(); reject(new Error("This photo could not be opened. Choose a JPG, PNG, or WebP image.")); };
    image.src = url;
  });
}
function renderAvatarChoices(container, selected = state.selectedAvatar) {
  const wrap = q(container); if (!wrap) return;
  wrap.replaceChildren();
  AVATARS.forEach(({ id, name }) => {
    const choice = el("button", `avatar-choice ${selected === id ? "selected" : ""}`); choice.type = "button"; choice.setAttribute("aria-pressed", String(selected === id)); choice.setAttribute("aria-label", `Choose ${name} avatar`);
    choice.append(avatarMark(id), el("span", "", name));
    choice.addEventListener("click", () => {
      state.selectedAvatar = id;
      if (state.profile) { state.profile.avatar = id; state.profile.avatarPhoto = ""; saveProfile(); renderProfile(); updateProfilePhotoControls(); }
      renderAvatarChoices("#avatar-options", id); renderAvatarChoices("#edit-avatar-options", id);
    });
    wrap.append(choice);
  });
}
function readStudy() { try { const value = JSON.parse(localStorage.getItem(STUDY_KEY) || "{}"); return { sessions: Array.isArray(value.sessions) ? value.sessions : [], active: value.active || null }; } catch { return { sessions: [], active: null }; } }
function saveStudy() { try { localStorage.setItem(STUDY_KEY, JSON.stringify(state.study)); } catch { toast("Could not save study time in this browser."); } }
function profileText(profile) { return [...(profile.skills || []), profile.moreSkills || ""].join(". "); }
function weekStartTimestamp(now = Date.now()) { const date = new Date(now); date.setHours(0, 0, 0, 0); date.setDate(date.getDate() - ((date.getDay() + 6) % 7)); return date.getTime(); }
function getStudySecondsThisWeek() {
  const now = Date.now(), startOfWeek = weekStartTimestamp(now), sessions = [...state.study.sessions];
  if (state.study.active) sessions.push({ ...state.study.active, endedAt: Math.min(now, Number(state.study.active.startedAt) + 12 * 60 * 60 * 1000) });
  return sessions.reduce((total, item) => {
    const start = Math.max(startOfWeek, Number(item.startedAt) || 0);
    const end = Math.min(now, Number(item.endedAt) || start);
    return total + Math.max(0, Math.floor((end - start) / 1000));
  }, 0);
}
function formatStudyTime(seconds) { const safeSeconds = Math.max(0, seconds); const minutes = Math.floor(safeSeconds / 60); const hours = Math.floor(minutes / 60); if (safeSeconds < 60) return `${Math.floor(safeSeconds)}s`; return hours ? `${hours}h ${minutes % 60}m` : `${minutes}m`; }
function updateStudySummary() { const caption = q("#stat-hours-caption"); if (caption) caption.textContent = `${formatStudyTime(getStudySecondsThisWeek())} studied this week · click to log`; }

function renderWelcome() {
  const profile = state.profile && typeof state.profile === "object" ? state.profile : null;
  const hasProfile = Boolean(profile);
  q("#login-heading").textContent = "Start your journey";
  q("#login-description").textContent = hasProfile ? "Set up a new profile. Saving it replaces the one shown below." : "Create a learner profile to build your career map.";
  q("#cover-saved-profile").classList.toggle("hidden", !hasProfile);
  q("#demo-login").classList.toggle("hidden", hasProfile);
  if (hasProfile) {
    q("#cover-profile-name").textContent = cleanText(profile.name) || "Saved profile";
    const roles = Array.isArray(profile.roles) ? profile.roles.filter(Boolean).slice(0, 2) : [];
    q("#cover-profile-roles").textContent = roles.join(" · ") || "Your learning workspace";
    paintAvatar(q("#cover-profile-avatar"), profile.avatar, profile.avatarPhoto);
  }
}

function showScreen(name) {
  q("#welcome-screen").classList.toggle("hidden", name !== "welcome");
  q("#onboarding-screen").classList.toggle("hidden", name !== "onboarding");
  q("#dashboard").classList.toggle("hidden", name !== "dashboard");
  q("#site-assistant").classList.toggle("hidden", name !== "dashboard");
}
function renderChoices(container, options, selected, type) {
  container.replaceChildren();
  options.forEach((value) => {
    const label = el("label", type === "role" ? "choice-card" : "skill-pick");
    const input = document.createElement("input"); input.type = "checkbox"; input.value = value; input.checked = selected.includes(value); input.dataset.choice = type;
    const copy = el("span", "choice-copy"); copy.append(el("b", "", value));
    if (type === "role") copy.append(el("small", "", "Explore this path"));
    label.append(input, copy, el("span", type === "role" ? "choice-check" : "pick-check", "✓"));
    container.append(label);
  });
}
function selectedFrom(container) { return qa('input[type="checkbox"]:checked', container).map((input) => input.value); }
function renderSkillChoices(container, selected = []) {
  const initial = selected.length ? selected : [NO_SKILLS];
  renderChoices(container, [...SKILLS, NO_SKILLS], initial, "skill");
  const inputs = qa('input[type="checkbox"]', container), none = inputs.find((input) => input.value === NO_SKILLS);
  if (none) {
    const label = none.closest("label");
    if (label) { label.classList.add("skill-pick-none"); label.querySelector(".choice-copy b").textContent = "None yet"; }
    inputs.forEach((input) => input.addEventListener("change", () => {
      if (input === none && input.checked) inputs.forEach((item) => { if (item !== none) item.checked = false; });
      else if (input.checked) none.checked = false;
      if (!inputs.some((item) => item !== none && item.checked)) none.checked = true;
    }));
  }
}
function selectedSkills(container) { return selectedFrom(container).filter((value) => value !== NO_SKILLS); }
function updateProfilePhotoControls() {
  const hasPhoto = Boolean(state.profile?.avatarPhoto);
  q("#remove-profile-photo")?.classList.toggle("hidden", !hasPhoto);
  const hint = q("#profile-photo-hint");
  if (hint) hint.textContent = hasPhoto ? "Professional photo saved in this browser." : "JPG, PNG or WebP · up to 5 MB. Saved in this browser.";
}
function setWizardStep(step) {
  qa(".form-step").forEach((node) => node.classList.toggle("hidden", Number(node.dataset.step) !== step));
  qa(".step-dot").forEach((node, index) => node.classList.toggle("active", index < step));
}
function openOnboarding() {
  q("#profile-form").reset();
  renderChoices(q("#role-options"), ROLES, [], "role");
  renderSkillChoices(q("#skill-options"));
  state.selectedAvatar = "sprout"; renderAvatarChoices("#avatar-options", state.selectedAvatar);
  q("#learner-location").value = "India"; q("#weekly-hours").value = "5";
  setWizardStep(1); showScreen("onboarding");
}
function enterDemo() {
  if (location.search) history.replaceState(null, "", location.pathname + location.hash);
  state.profile = { name: "Sam", stage: "Student", location: "India", roles: ["Data Analyst"], skills: ["Excel", "SQL", "Python", "Tableau"], moreSkills: "I have made dashboards for college projects and understand basic statistics.", hoursPerWeek: 5, done: [], roleUrl: "", company: "", roleNotes: "", avatar: "sprout" };
  state.currentRole = "Data Analyst"; saveProfile(); showScreen("dashboard"); renderProfile(); navigate("overview"); runAnalysis();
}

q("#create-profile-start").addEventListener("click", () => {
  if (location.search) history.replaceState(null, "", location.pathname + location.hash);
  openOnboarding();
});
q("#back-to-welcome").addEventListener("click", () => showScreen("welcome"));
q("#demo-login").addEventListener("click", () => {
  if (location.search) history.replaceState(null, "", location.pathname + location.hash);
  const existing = readProfile();
  if (existing) { state.profile = existing; state.currentRole = existing.roles?.[0] || "Data Analyst"; showScreen("dashboard"); renderProfile(); navigate("overview"); runAnalysis(); }
  else enterDemo();
});
q("#profile-form").addEventListener("click", (event) => {
  if (event.target.closest(".next-step")) {
    const current = Number(event.target.closest(".form-step").dataset.step);
    if (current === 1 && !cleanText(q("#learner-name").value)) { q("#learner-name").focus(); toast("Add your name to continue."); return; }
    if (current === 2 && selectedFrom(q("#role-options")).length === 0) { toast("Choose at least one career path."); return; }
    if (current < 3) setWizardStep(current + 1);
  }
  if (event.target.closest(".prev-step")) setWizardStep(Number(event.target.closest(".form-step").dataset.step) - 1);
});
q("#add-role").addEventListener("click", () => addChoice("#role-options", "#custom-role", ROLES, "role"));
q("#profile-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const roles = selectedFrom(q("#role-options"));
  if (!roles.length) { setWizardStep(2); toast("Choose one or more career paths first."); return; }
  const hoursPerWeek = Number(q("#weekly-hours").value);
  if (!Number.isInteger(hoursPerWeek) || hoursPerWeek < 1 || hoursPerWeek > 80) { setWizardStep(3); q("#weekly-hours").focus(); toast("Enter a weekly study target from 1 to 80 hours."); return; }
  state.profile = { name: cleanText(q("#learner-name").value), stage: q("#learner-stage").value, location: cleanText(q("#learner-location").value) || "India", roles, skills: selectedSkills(q("#skill-options")), moreSkills: cleanText(q("#more-skills").value), hoursPerWeek, done: [], company: "", roleNotes: "", roleUrl: "", avatar: state.selectedAvatar };
  state.pathAnalyses = {};
  state.currentRole = roles[0]; saveProfile(); showScreen("dashboard"); renderProfile(); navigate("overview"); runAnalysis(); toast("Your learning profile is ready.");
});
function addChoice(containerSelector, inputSelector, defaults, type) {
  const input = q(inputSelector), value = cleanText(input.value);
  if (!value) return;
  const container = q(containerSelector), roles = [...new Set([...defaults, ...qa('input[type="checkbox"]', container).map((node) => node.value), value])];
  renderChoices(container, roles, selectedFrom(container).concat(value), type); input.value = "";
}

qa(".nav-item").forEach((button) => button.addEventListener("click", () => navigate(button.dataset.view)));
document.addEventListener("click", (event) => {
  const target = event.target.closest("[data-open-view]");
  if (target) { event.preventDefault(); navigate(target.dataset.openView); }
});
q("#profile-nav").addEventListener("click", () => navigate("profile"));
q("#top-profile").addEventListener("click", () => navigate("profile"));

const WORKSPACE_COMMANDS = [
  { label: "Go to home", detail: "Your current role and next milestone", view: "overview" },
  { label: "Open career map", detail: "See your matched skills and learning plan", view: "career-map" },
  { label: "Research a role", detail: "Compare yourself with a company posting", view: "skills" },
  { label: "Browse learning resources", detail: "Videos, course searches, and practice links", view: "learning" },
  { label: "Edit your profile", detail: "Update roles, skills, pace, or avatar", view: "profile" },
  { label: "Ask the Guide", detail: "Get help with your plan or workspace", action: "guide" },
];
let commandIndex = 0;
function renderCommandResults(query = "") {
  const results = q("#command-results"); if (!results) return;
  const normalized = cleanText(query).toLowerCase();
  const matches = WORKSPACE_COMMANDS.filter((item) => `${item.label} ${item.detail}`.toLowerCase().includes(normalized));
  commandIndex = Math.min(commandIndex, Math.max(0, matches.length - 1)); results.replaceChildren();
  if (!matches.length) { results.append(el("p", "command-empty", "No shortcuts match that search.")); return; }
  matches.forEach((item, index) => {
    const button = el("button", `command-result ${index === commandIndex ? "is-active" : ""}`); button.type = "button"; button.setAttribute("role", "option"); button.setAttribute("aria-selected", String(index === commandIndex));
    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg"); icon.setAttribute("viewBox", "0 0 24 24"); icon.setAttribute("aria-hidden", "true"); icon.innerHTML = item.action === "guide" ? '<path d="M12 3a8 8 0 1 0 0 16h4l3 2v-6.5A8 8 0 0 0 12 3Z"></path><path d="M8 11h.01M12 11h.01M16 11h.01"></path>' : '<path d="M5 12h14M12 5l7 7-7 7"></path>';
    const copy = el("span", "command-copy"); copy.append(el("b", "", item.label), el("small", "", item.detail)); button.append(icon, copy); button.addEventListener("click", () => runCommand(item)); results.append(button);
  });
}
function runCommand(item) {
  q("#command-palette").close();
  if (item.action === "guide") { q("#assistant-panel").classList.remove("hidden"); q("#assistant-input").focus(); return; }
  navigate(item.view);
}
function openCommandPalette() { commandIndex = 0; q("#command-input").value = ""; renderCommandResults(); q("#command-palette").showModal(); q("#command-input").focus(); }
q("#command-trigger").addEventListener("click", openCommandPalette);
q("#command-close").addEventListener("click", () => q("#command-palette").close());
q("#command-input").addEventListener("input", (event) => { commandIndex = 0; renderCommandResults(event.target.value); });
q("#command-input").addEventListener("keydown", (event) => {
  const buttons = qa(".command-result", q("#command-results")); if (!buttons.length) return;
  if (event.key === "ArrowDown" || event.key === "ArrowUp") { event.preventDefault(); commandIndex = (commandIndex + (event.key === "ArrowDown" ? 1 : buttons.length - 1)) % buttons.length; renderCommandResults(q("#command-input").value); }
  if (event.key === "Enter") { event.preventDefault(); buttons[commandIndex].click(); }
});
document.addEventListener("keydown", (event) => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); if (!q("#command-palette").open) openCommandPalette(); } });

function navigate(view) {
  if (view === "profile") renderEditProfile();
  qa(".view-section").forEach((section) => section.classList.toggle("hidden", section.id !== `view-${view}`));
  qa(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.view === view));
  const label = { overview: "Home", "career-map": "Career map", skills: "Skills", learning: "Learn", profile: "Profile" }[view] || "Home";
  q("#current-section-name").textContent = label; state.currentView = view;
  if (view === "career-map" || view === "learning") {
    if (state.pendingPathAnalysis?.role === state.currentRole) { state.analysis = state.pendingPathAnalysis; state.analysisKey = ""; renderAnalysis(state.analysis); state.pendingPathAnalysis = null; }
    else runAnalysis();
  }
  if (view === "skills") loadLeaderboard(state.currentRole || state.profile?.roles?.[0]);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderProfile() {
  const profile = state.profile; if (!profile) return;
  const first = profile.name.split(/\s+/)[0];
  q("#greeting-name").textContent = first ? `, ${first}` : "";
  q("#sidebar-name").textContent = profile.name || "Learner";
  state.selectedAvatar = profile.avatar || state.selectedAvatar || "sprout";
  paintAvatar(q("#sidebar-avatar"), state.selectedAvatar, profile.avatarPhoto); paintAvatar(q("#top-profile"), state.selectedAvatar, profile.avatarPhoto); paintAvatar(q("#profile-large-avatar"), state.selectedAvatar, profile.avatarPhoto);
  q("#today-label").textContent = new Intl.DateTimeFormat(undefined, { weekday: "long", month: "short", day: "numeric" }).format(new Date());
  q("#hero-role").textContent = state.currentRole || profile.roles[0] || "Your next role";
  q("#hero-subtitle").textContent = profile.company ? `${profile.currentPosition || state.currentRole} at ${profile.company}` : "Role requirements and your next skills.";
  const hours = q("#stat-hours"); hours.replaceChildren(document.createTextNode(String(profile.hoursPerWeek || 5)), el("i", "", "hrs / week"));
  updateStudySummary();
  q("#stat-goals").textContent = profile.roles.length;
  q("#nav-goal-count").textContent = profile.roles.length;
  q("#sidebar-progress-label").textContent = profile.done?.length ? `${profile.done.length} step${profile.done.length === 1 ? "" : "s"} complete` : "No steps complete";
  const availableSteps = state.analysis?.plan || [];
  const completedSteps = availableSteps.filter((step) => profile.done?.includes(step.id || step.skill) || profile.done?.includes(step.skill)).length;
  setProgress(q("#sidebar-progress-bar"), availableSteps.length ? Math.round(completedSteps / availableSteps.length * 100) : 0);
  q("#sidebar-progress-sub").textContent = "Progress saves in this browser.";
  q("#overview-goals").replaceChildren();
  profile.roles.forEach((role, index) => {
    const card = el("button", `goal-row ${role === state.currentRole ? "selected" : ""}`); card.type = "button";
    const dot = el("span", `goal-dot goal-dot-${index % 4}`, String(index + 1));
    const info = el("span", "goal-copy"); info.append(el("b", "", role), el("small", "", roleValue(role, state.pathAnalyses[role])));
    card.append(dot, info, el("span", "goal-arrow", role === state.currentRole ? "Selected" : "Open"));
    card.addEventListener("click", () => { state.currentRole = role; renderProfile(); navigate("career-map"); });
    q("#overview-goals").append(card);
  });
  q("#map-title").textContent = state.currentRole || profile.roles[0];
  q("#map-pace-value").textContent = `${profile.hoursPerWeek || 5} hours / week`;
  renderRoleTabs();
  renderPathInsights();
}
function renderRoleTabs() {
  if (!state.profile) return;
  const tabs = q("#map-role-tabs"); tabs.replaceChildren();
  state.profile.roles.forEach((role) => {
    const button = el("button", `role-tab ${role === state.currentRole ? "active" : ""}`, role); button.type = "button";
    button.addEventListener("click", () => { state.currentRole = role; renderProfile(); runAnalysis(); }); tabs.append(button);
  });
}

function leaderboardProfileKey(role) { return `${state.profile?.location || "India"}|${role}`.toLowerCase(); }
const SKILL_EXPLANATIONS = {
  "SQL": ["A language for asking questions of data stored in tables, such as orders or customers.", "Find the five most popular products in a sales table."],
  "Excel": ["A spreadsheet tool for organizing, checking, calculating, and summarizing information.", "Clean a small sales sheet, make a pivot table, and chart monthly totals."],
  "Python": ["A programming language often used to automate work and explore or transform data.", "Load a CSV, calculate a few summary values, and explain one pattern."],
  "R": ["A programming language designed for statistics, data analysis, and clear charts.", "Compare two groups in a small dataset and plot the result."],
  "Statistics": ["Methods for describing data and judging how much confidence to place in a pattern.", "Compare two groups and explain both the result and its uncertainty."],
  "Data visualization": ["Presenting information visually so people can spot patterns and make decisions.", "Make a chart with a clear title, labeled axes, and one takeaway."],
  "Tableau": ["A visual analytics tool for exploring data and building interactive dashboards.", "Build a small dashboard that answers one business question."],
  "Power BI": ["Microsoft's tools for connecting, modeling, and reporting data in interactive dashboards.", "Create a simple data model, one measure, and a filterable report."],
  "Data cleaning": ["Finding and fixing issues such as missing values, duplicates, or inconsistent formats.", "Check a public dataset for duplicates and missing values, then document each fix."],
  "Communication": ["Explaining work and findings so another person can understand what they mean and what to do.", "Present one finding in three slides for someone who does not work with data."],
  "Critical thinking": ["Breaking a question into parts, checking evidence, and noticing assumptions or limits.", "Write down two possible explanations for a result and what evidence would distinguish them."],
  "Machine learning": ["Teaching a computer to find patterns in examples and use them to make predictions.", "Train a simple model on a small dataset and compare its predictions with known answers."],
  "ETL": ["A process for moving data from its source, changing it into a useful format, and saving it somewhere ready to use.", "Read a public CSV, standardize its dates and column names, then save the cleaned result."],
  "Cloud platforms": ["Online services for running applications and storing or processing data without managing all the hardware yourself.", "Deploy a small demo using a free tier and note the setup steps and usage limits."],
  "Git": ["A tool that records changes to files so you can revisit earlier versions and work safely with others.", "Create a repository, save a few small commits, and describe what each changed."],
  "Data modeling": ["Planning how data tables and fields fit together so queries and reports have consistent meaning.", "Sketch two related tables and mark their shared key before building a report."],
  "A/B testing": ["A controlled comparison of two versions to see which better meets a defined goal.", "Write a hypothesis, choose one success measure, and explain what result would change your decision."],
  "Data engineering": ["Building dependable systems that collect, transform, and deliver data for analysis or products.", "Create a small repeatable pipeline and check that its output is complete and correctly formatted."],
  "JavaScript": ["A programming language that makes websites and many applications respond to user actions.", "Build a small page interaction and handle both a normal input and an empty one."],
  "HTML & CSS": ["HTML structures webpage content; CSS controls its layout, typography, and appearance.", "Build a simple responsive page with headings, a form, and visible keyboard focus."],
  "Figma": ["A design tool for creating interface layouts, prototypes, and shared design files.", "Prototype one important screen and revise it after watching someone try it."],
  "User research": ["Learning about people's needs and behavior through methods such as interviews and usability sessions.", "Ask three people to try a task and summarize what confused them without naming them."],
  "UX design": ["Designing how a product works for people, including its flow, clarity, and accessibility.", "Improve one short user flow and check it with keyboard navigation."],
  "Agile": ["A way of organizing work into short cycles so a team can learn and adjust as it goes.", "Break a project into a small first delivery, a review point, and the next improvement."],
  "Project management": ["Planning and coordinating work, timing, people, and risks so a project can reach its goal.", "Plan a two-week project with milestones, dependencies, and one likely risk."],
  "Customer service": ["Helping customers solve problems and understand the product or service they use.", "Draft a clear response to a common problem and list what you would check before replying."],
  "Sales": ["Understanding a customer's needs and helping them decide whether a product or service fits.", "Practice a short discovery conversation and summarize the customer's goal before suggesting a solution."],
  "Writing": ["Putting information into clear written form for a specific reader and purpose.", "Rewrite a technical explanation for a new teammate and ask them what remains unclear."],
  "Leadership": ["Helping a group make progress by setting direction, supporting people, and handling decisions.", "Write a short plan that clarifies the goal, owners, and how the team will raise blockers."],
  "Research": ["Finding and comparing trustworthy information to answer a focused question.", "Compare three relevant sources and note where they agree, differ, and leave gaps."],
  "Java": ["A general-purpose programming language used to build applications and backend services.", "Write a small program that reads input, checks it, and produces a useful result."],
  "C#": ["A programming language commonly used for applications, services, and the .NET platform.", "Build a small .NET utility and add a check for an invalid input."],
  "APIs": ["An agreed way for software systems to request information or actions from each other.", "Call a public API, inspect its response, and handle a missing or unsuccessful result."],
  "Testing": ["Checking software or data against expected results so problems are caught before release.", "Add a check for one normal case and one likely edge case, then record what the checks catch."],
  "Security fundamentals": ["Basic practices for protecting systems and information from unauthorized access or misuse.", "Use a legal training lab to identify a risk and write down a safe way to reduce it."],
  "Linux": ["An operating system often used for servers, software tools, and command-line work.", "Use a shell command to find and summarize matching lines in a sample log."],
  "Networking": ["How computers find each other and send information across local and internet connections.", "Trace a DNS lookup in a beginner lab and sketch the path a request takes."],
  "Product strategy": ["Choosing which user and business problems a product should solve and why.", "Compare two possible improvements against user value, effort, and the product goal."],
  "Requirements analysis": ["Clarifying what people need from a system and turning it into details a team can build and check.", "Turn a request into a user story with clear acceptance checks."],
  "SEO": ["Improving a webpage so people can find and understand it through search engines.", "Check one public page for a clear title, useful headings, relevant content, and helpful links."],
  "Content strategy": ["Planning what content to create, who it serves, and how it stays useful over time.", "Plan a short set of articles for one audience and give each a clear purpose."],
};

function showLeaderboardSkillDetails(item, board, role, sampleData, haveSkill) {
  const explanation = SKILL_EXPLANATIONS[item.skill] || [
    `${item.skill} is a skill named in listings for ${role}. The role map can help you connect it to a practical task.`,
    `Choose one small task related to ${role} where you can try ${item.skill} and explain your result.`,
  ];
  const matchingData = [
    state.analysis?.role?.toLowerCase() === role.toLowerCase() ? state.analysis : null,
    state.pathAnalyses[role],
  ].find((data) => Array.isArray(data?.skills));
  const roleSkill = matchingData?.skills.find((skill) => skill.name?.toLowerCase() === item.skill.toLowerCase());
  const planStep = matchingData?.plan?.find((step) => step.skill?.toLowerCase() === item.skill.toLowerCase());
  const count = Math.max(0, Number(item.count) || 0);
  const total = Math.max(0, Number(board.jobCount) || 0);
  const percent = Math.max(0, Math.min(100, Number(item.percent) || 0));
  const listings = total === 1 ? "listing" : "listings";
  const evidence = `${count} of ${total} ${sampleData ? `sample role ${listings}` : listings} (${percent}%).`;

  openInsight(item.skill, "A plain-language explanation, an example, and a practical way to try this skill.", "SKILL DETAILS · ROLE FIT");
  const content = q("#insight-content");
  content.append(el("div", "insight-summary-strip", `${role} · ${haveSkill ? "You listed this skill" : "Not in your profile yet"}`));

  const meaning = el("section", "skill-detail-section");
  meaning.append(el("h3", "", "What this skill means"), el("p", "", explanation[0]));
  meaning.append(el("p", "skill-detail-example", `For example: ${explanation[1]}`));
  content.append(meaning);

  const roleContext = el("section", "skill-detail-section");
  roleContext.append(el("h3", "", "What the listings tell you"));
  const defaultReason = `${item.skill} is commonly used in ${role} work.`;
  const roleReason = roleSkill?.reason?.trim();
  const genericReason = !roleReason || roleReason.toLowerCase() === defaultReason.toLowerCase()
    || / helps .+ teams turn their work into clear, reliable outcomes\.?$/i.test(roleReason);
  const evidenceNote = sampleData
    ? "These are sample listings, so treat the count as an example rather than a requirement for every job."
    : "This count describes these listings only; requirements vary between employers.";
  roleContext.append(el("p", "", `${item.skill} was mentioned in ${evidence} ${evidenceNote}`));
  if (!genericReason) roleContext.append(el("p", "skill-detail-example", `Role guidance: ${roleReason}`));
  content.append(roleContext);

  const practice = el("section", "skill-detail-section");
  practice.append(el("h3", "", "A practical next step"));
  practice.append(el("p", "", roleSkill?.task || planStep?.task || explanation[1]));
  practice.append(el("p", "skill-detail-example", `Save as evidence: ${roleSkill?.proof || planStep?.proof || "Keep your work and write one sentence about what it demonstrates."}`));
  content.append(practice);

  const profile = el("section", "skill-detail-section");
  profile.append(el("h3", "", "Your profile match"));
  profile.append(el("p", "", haveSkill
    ? "You marked this skill in your profile. Skill Bridge uses your self-report; it does not test your proficiency."
    : "This skill is not listed in your profile. If you have used it, add it under Edit profile to update your match."));
  content.append(profile);

  const sourceUrl = /adzuna/i.test(board.source || "") && !sampleData ? "https://www.adzuna.com" : "";
  content.append(sourceLink(board.source || "Skill Bridge role listings", "Listings source", sourceUrl));
}

function renderLeaderboard() {
  const role = q("#leaderboard-role").value || state.currentRole;
  const board = state.leaderboards[leaderboardProfileKey(role)];
  const wrap = q("#leaderboard-list");
  if (!board) { wrap.replaceChildren(el("div", "empty-library", "Loading skills for this job title…")); return; }
  const sampleData = /sample/i.test(board.source || "");
  q("#leaderboard-source").textContent = `${board.jobCount} job listings${sampleData ? " · example data" : ` · ${board.source}`}`;
  const have = new Set((state.profile?.skills || []).map((value) => value.toLowerCase()));
  const rows = (board.skills || []).filter((item) => item.count >= state.leaderboardMin);
  rows.sort((a, b) => state.leaderboardSort === "asc" ? a.count - b.count || a.skill.localeCompare(b.skill) : b.count - a.count || a.skill.localeCompare(b.skill));
  wrap.classList.toggle("is-list", state.leaderboardLayout === "list"); wrap.replaceChildren();
  if (!rows.length) { wrap.append(el("div", "empty-library", "No skills match this filter.")); return; }
  rows.forEach((item, index) => {
    const card = el("article", `leaderboard-item ${item.skill.toLowerCase() === state.highlightedSkill.toLowerCase() ? "is-highlighted" : ""}`);
    const top = el("div", "leaderboard-item-top");
    const skillButton = el("button", "leaderboard-skill-trigger"); skillButton.type = "button";
    skillButton.setAttribute("aria-label", `Learn about ${item.skill}`); skillButton.setAttribute("aria-haspopup", "dialog");
    skillButton.append(el("span", "", item.skill));
    const infoIcon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    infoIcon.setAttribute("viewBox", "0 0 20 20"); infoIcon.setAttribute("aria-hidden", "true");
    infoIcon.innerHTML = '<circle cx="10" cy="10" r="7.2"></circle><path d="M10 9v4m0-6h.01"></path>';
    skillButton.append(infoIcon);
    skillButton.addEventListener("click", () => showLeaderboardSkillDetails(item, board, role, sampleData, have.has(item.skill.toLowerCase())));
    const heading = el("h3", ""); heading.append(skillButton);
    top.append(el("span", "leaderboard-rank", String(index + 1).padStart(2, "0")), heading);
    const status = have.has(item.skill.toLowerCase()) ? "You have" : "Learn next";
    top.append(el("span", `leaderboard-match ${status === "You have" ? "matched" : ""}`, status)); card.append(top);
    const metric = el("div", "leaderboard-metric"); metric.append(el("b", "", `${item.count}`), el("span", "", `of ${board.jobCount} listings`)); card.append(metric);
    const track = el("div", "leaderboard-track"); const fill = el("i"); fill.style.width = `${item.percent}%`; track.append(fill); card.append(track);
    card.append(el("small", "leaderboard-percent", `${item.percent}% mention this skill`));
    const context = el("div", "leaderboard-skill-context");
    context.append(el("span", "", `${item.skill} appears in ${item.count} of ${board.jobCount} ${sampleData ? "sample " : ""}role listings.`));
    const liveSourceUrl = /adzuna/i.test(board.source || "") && !sampleData ? "https://www.adzuna.com" : "";
    context.append(sourceLink(board.source || "Sample role descriptions", "Source", liveSourceUrl)); card.append(context); wrap.append(card);
  });
}
async function loadLeaderboard(role, force = false) {
  if (!state.profile || !role) return;
  const select = q("#leaderboard-role"); const roles = [...new Set(state.profile.roles || [])];
  if (!roles.includes(role)) roles.unshift(role);
  select.replaceChildren(...roles.slice(0, 12).map((title) => { const option = el("option", "", title); option.value = title; return option; }));
  select.value = role;
  state.currentRole = role; renderProfile(); renderLeaderboard();
  const key = leaderboardProfileKey(role); if (!force && state.leaderboards[key]) { renderLeaderboard(); return state.leaderboards[key]; }
  q("#leaderboard-source").textContent = "Loading listings…";
  try {
    const response = await fetch("/api/leaderboard", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ role, location: state.profile.location || "India" }) });
    const board = await response.json(); if (!response.ok) throw new Error(board.error || "Could not load this leaderboard.");
    state.leaderboards[key] = board;
    try { localStorage.setItem("skillBridge.leaderboards.v1", JSON.stringify(state.leaderboards)); } catch {}
    renderLeaderboard(); return board;
  } catch (error) {
    let cached = state.leaderboards[key];
    if (!cached) {
      try {
        if (!state.offlineBoards) {
          const staticUrl = new URL("data/skills_leaderboard.json", document.baseURI);
          const fallbackResponse = await fetch(staticUrl);
          if (!fallbackResponse.ok) throw new Error("Offline sample unavailable.");
          state.offlineBoards = await fallbackResponse.json();
        }
        const match = Object.keys(state.offlineBoards).find((title) => title.toLowerCase() === role.toLowerCase());
        if (match) cached = { ...state.offlineBoards[match], role, location: state.profile.location || "India" };
      } catch {}
    }
    if (cached) {
      state.leaderboards[key] = cached;
      try { localStorage.setItem("skillBridge.leaderboards.v1", JSON.stringify(state.leaderboards)); } catch {}
      q("#leaderboard-source").textContent = cached.source?.includes("offline") ? `${cached.jobCount} sample listings · offline` : "Saved local results · refresh when online";
      renderLeaderboard();
    } else {
      q("#leaderboard-source").textContent = "No saved or bundled sample for this job title.";
      q("#leaderboard-list").replaceChildren(el("div", "empty-library", "Add a standard job title or connect the job listings API."));
    }
  }
}

function openInsight(title, description, kicker = "CAREER INSIGHT") {
  q("#insight-kicker").textContent = kicker;
  q("#insight-title").textContent = title;
  q("#insight-description").textContent = description;
  q("#insight-content").replaceChildren();
  q("#insight-dialog").showModal();
}
function skillInsightRows(skills, emptyText) {
  const wrap = el("div", "insight-skill-list");
  if (!skills.length) { wrap.append(el("p", "insight-empty", emptyText)); return wrap; }
  skills.forEach((skill) => {
    const row = el("article", `insight-skill-row ${skill.status === "strength" ? "is-covered" : "is-gap"}`);
    const head = el("div", "insight-skill-head");
    head.append(el("b", "", skill.name), el("span", `insight-status ${skill.status === "strength" ? "is-covered" : "is-gap"}`, skill.status === "strength" ? "HAVE · covered" : "LEARN NEXT"));
    row.append(head);
    addMore(row, skill.reason || (skill.status === "strength" ? "You listed this in your profile." : "This role map recommends learning this skill."), "insight-skill-reason", 145);
    row.append(sourceLink(skill.status === "strength" ? "Your browser profile" : skill.source, "Source", skill.status === "strength" ? "" : skill.sourceUrl || ""));
    wrap.append(row);
  });
  return wrap;
}
function showRoleSkills(matchedOnly = false) {
  const data = state.analysis?.role === state.currentRole ? state.analysis : state.pathAnalyses[state.currentRole];
  const skills = (data?.skills || []).filter((skill) => !matchedOnly || skill.status === "strength");
  const title = matchedOnly ? "Skills you already have" : `${state.currentRole} skills`;
  const description = matchedOnly
    ? "These are marked covered because you included them in your profile. Add or edit evidence in Profile if you want to be more specific."
    : "Every mapped skill for this role, grouped as skills already in your profile and skills to build.";
  openInsight(title, description, matchedOnly ? "PROFILE MATCH" : "ROLE SKILLS");
  const content = q("#insight-content");
  if (!data) { content.append(el("p", "insight-empty", "Build this role map to see its full skill list.")); return; }
  content.append(el("div", "insight-summary-strip", `${skills.length} ${matchedOnly ? "covered skills" : "role skills"} · ${data.source || "role analysis"}`));
  content.append(skillInsightRows(skills, "No skills in this group yet. Your profile and role map may still be loading."));
}
async function readRoleToolsCatalog() {
  if (state.roleToolsCatalog) return state.roleToolsCatalog;
  try {
    const response = await fetch("data/role_tools.json", { cache: "force-cache" });
    if (!response.ok) throw new Error("Tool catalog unavailable.");
    state.roleToolsCatalog = await response.json();
  } catch { state.roleToolsCatalog = {}; }
  return state.roleToolsCatalog;
}
async function showCareerGoals() {
  openInsight("Your career goals", "Explore practical software used in each role. AI tool suggestions appear when you opt in to a role map analysis.", "CAREER GOALS · TOOLS");
  const content = q("#insight-content");
  const catalog = await readRoleToolsCatalog();
  (state.profile?.roles || []).forEach((role, index) => {
    const data = state.pathAnalyses[role] || (state.analysis?.role === role ? state.analysis : null);
    const tools = data?.tools?.length ? data.tools : Object.entries(catalog).find(([title]) => title.toLowerCase() === role.toLowerCase())?.[1] || [
      { name: "GitHub", purpose: `Browse public starter projects related to ${role}.` },
      { name: "Google Workspace", purpose: `Write up and share a small ${role} project.` },
    ];
    const card = el("article", `goal-tool-card goal-tool-${index % 4}`);
    const head = el("div", "goal-tool-head"); head.append(el("span", "goal-tool-index", String(index + 1).padStart(2, "0")), el("h3", "", role));
    if (data && !data.error) head.append(el("span", "path-readiness", `${data.readiness}%`));
    card.append(head);
    const focus = el("p", "goal-focus", roleValue(role, data)); card.append(focus);
    const list = el("div", "goal-tool-list");
    tools.slice(0, 8).forEach((tool) => {
      const item = el("div", "goal-tool-item");
      const title = el("div", "goal-tool-title"); title.append(el("b", "", tool.name), el("span", "tool-source", tool.source || (data?.aiMode === "gemini" ? "Gemini guided" : "role examples")));
      item.append(title); addMore(item, tool.purpose || `Explore how ${tool.name} supports common ${role} tasks.`, "goal-tool-purpose", 118);
      const link = el("a", "tool-doc-link", "Explore this tool ↗"); link.href = safeUrl(tool.url || `https://www.google.com/search?q=${encodeURIComponent(`${tool.name} official documentation`)}`); link.target = "_blank"; link.rel = "noopener noreferrer"; item.append(link);
      list.append(item);
    });
    card.append(list);
    const footer = el("div", "goal-tool-footer"); footer.append(el("small", "insight-origin", data?.tools?.some((tool) => String(tool.source || "").includes("role guidance")) ? `Tool suggestions · ${data.aiMode} + role context` : "Tool suggestions · Skill Bridge role guide"));
    const open = el("button", "text-button", "Open career map →"); open.type = "button";
    open.addEventListener("click", () => { q("#insight-dialog").close(); state.currentRole = role; state.pendingPathAnalysis = data && !data.error ? data : null; renderProfile(); navigate("career-map"); });
    footer.append(open); card.append(footer); content.append(card);
  });
}
function renderStudyDialog() {
  const content = q("#insight-content"), active = state.study.active;
  const seconds = getStudySecondsThisWeek(), targetSeconds = (state.profile?.hoursPerWeek || 5) * 3600;
  const hours = Math.floor(seconds / 3600), minutes = Math.floor((seconds % 3600) / 60);
  const activeElapsed = active ? Math.min(Date.now() - active.startedAt, 12 * 60 * 60 * 1000) : 0;
  q("#study-week-total").textContent = formatStudyTime(seconds);
  setProgress(q("#study-week-progress"), targetSeconds ? seconds / targetSeconds * 100 : 0);
  q("#study-week-caption").textContent = `${hours}h ${minutes}m tracked · ${state.profile?.hoursPerWeek || 5}h weekly target`;
  q("#study-active-caption").textContent = active ? `Session running for ${active.role} · ${formatStudyTime(Math.floor(activeElapsed / 1000))}` : `No active session · selected role: ${state.currentRole}`;
  const toggle = q("#study-toggle"); toggle.textContent = active ? "Stop study session" : "Start study session"; toggle.classList.toggle("button-danger", Boolean(active));
  updateStudySummary();
  if (!content.contains(toggle)) return;
}
function showStudyTime() {
  openInsight("Study time this week", "Track focused learning sessions. Your logs stay in this browser and are not shared unless you ask The Guide to use your learning context.", "WEEKLY LEARNING LOG");
  const content = q("#insight-content");
  const summary = el("div", "study-summary");
  const total = el("b", "study-week-total", "0m"); total.id = "study-week-total";
  const track = el("div", "study-progress-track"); const fill = el("i"); fill.id = "study-week-progress"; track.append(fill);
  const caption = el("small", "study-week-caption"); caption.id = "study-week-caption";
  summary.append(el("span", "section-kicker", "THIS WEEK · MON–SUN"), total, track, caption);
  content.append(summary);
  const active = el("p", "study-active-caption"); active.id = "study-active-caption"; content.append(active);
  const toggle = el("button", "button button-primary", "Start study session"); toggle.id = "study-toggle"; toggle.type = "button"; content.append(toggle);
  toggle.addEventListener("click", () => {
    if (state.study.active) {
      const startedAt = Number(state.study.active.startedAt), endedAt = Math.min(Date.now(), startedAt + 12 * 60 * 60 * 1000);
      state.study.sessions.push({ ...state.study.active, endedAt }); state.study.active = null;
    } else {
      state.study.sessions = state.study.sessions.filter((session) => Date.now() - Number(session.endedAt || 0) < 120 * 24 * 60 * 60 * 1000);
      state.study.active = { role: state.currentRole || state.profile?.roles?.[0] || "Career learning", startedAt: Date.now() };
    }
    saveStudy(); renderStudyDialog();
  });
  renderStudyDialog();
  clearInterval(state.studyTimer); state.studyTimer = window.setInterval(() => { if (q("#insight-dialog").open && q("#study-week-total")) renderStudyDialog(); else clearInterval(state.studyTimer); }, 15000);
}
function showDashboardInsight(action) {
  if (action === "roleSkills") showRoleSkills(false);
  if (action === "matchedSkills") showRoleSkills(true);
  if (action === "studyTime") showStudyTime();
  if (action === "careerGoals") showCareerGoals();
}
qa(".stat-card[data-dashboard-action]").forEach((card) => {
  card.addEventListener("click", () => showDashboardInsight(card.dataset.dashboardAction));
  card.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); showDashboardInsight(card.dataset.dashboardAction); } });
});
q("#insight-close").addEventListener("click", () => q("#insight-dialog").close());
q("#insight-dialog").addEventListener("close", () => clearInterval(state.studyTimer));

function renderPathInsights(statusText = "") {
  const grid = q("#path-insight-grid");
  if (!grid || !state.profile) return;
  grid.replaceChildren();
  (state.profile.roles || []).forEach((role) => {
    const data = state.pathAnalyses[role];
    const card = el("article", "path-insight-card");
    const head = el("div", "path-insight-head");
    head.append(el("span", "path-role-symbol", "↗"), el("h4", "", role));
    if (data && !data.error) head.append(el("span", "path-readiness", `${data.readiness}%`));
    card.append(head);
    if (data && !data.error) {
      const strengths = data.skills.filter((skill) => skill.status === "strength").length;
      card.append(el("p", "path-match-summary", `${strengths} of ${data.skills.length} skills in your profile`));
      const missing = data.skills.filter((skill) => skill.status !== "strength").slice(0, 3);
      if (missing.length) card.append(el("p", "path-top-gaps", `Next: ${missing.map((skill) => skill.name).join(" · ")}`));
      const jobSource = data.sources?.find((source) => source.area === "Role requirements");
      card.append(el("small", "path-origin", `${jobSource?.name || data.source} · ${data.aiMode === "gemini" ? "Gemini skills" : "Local match"}`));
      const open = el("button", "text-button", "Open plan →"); open.type = "button";
      open.addEventListener("click", () => { state.currentRole = role; state.pendingPathAnalysis = data; renderProfile(); navigate("career-map"); });
      card.append(open);
    } else {
      card.append(el("p", "path-match-summary", data?.error || "Not analyzed yet."));
      card.append(el("small", "path-origin", "Analyze to see skills, sources, and course searches."));
    }
    grid.append(card);
  });
  const status = q("#path-analysis-status");
  if (statusText && status) status.textContent = statusText;
  else if (status && Object.keys(state.pathAnalyses).length) status.textContent = `${Object.keys(state.pathAnalyses).length} saved role maps · stored in this browser`;
}

q("#analyze-all-paths").addEventListener("click", async () => {
  if (!state.profile?.roles?.length) return;
  const button = q("#analyze-all-paths"), status = q("#path-analysis-status");
  const roles = [...new Set(state.profile.roles)].slice(0, 12), useGemini = q("#all-gemini-opt-in").checked;
  const profileAtStart = profileText(state.profile), location = state.profile.location || "India", hoursPerWeek = state.profile.hoursPerWeek || 5;
  button.disabled = true; button.textContent = "Analyzing…";
  status.textContent = `Starting ${roles.length} role maps · up to 3 at a time${useGemini ? " · AI enabled" : " · local matching"}.`;
  let next = 0, complete = 0, usedGemini = 0, failures = 0;
  const worker = async () => {
    while (next < roles.length) {
      const role = roles[next++];
      try {
        const response = await fetch("/api/analyze", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ role, location, profile: profileAtStart, hoursPerWeek, useAI: useGemini, useGemini, geminiVideoRanking: false }) });
        const result = await readJson(response);
        if (!response.ok) throw new Error(result.error || "Role analysis failed.");
        state.pathAnalyses[role] = result;
        if (result.aiMode === "gemini") usedGemini++;
      } catch (error) {
        failures++;
        state.pathAnalyses[role] = { role, error: error.message || "Could not analyze this role." };
      }
      complete++;
      savePathAnalyses();
      renderPathInsights(`${complete} of ${roles.length} roles ready${failures ? ` · ${failures} need retry` : ""}${useGemini ? ` · AI used for ${usedGemini}` : " · local matching"}.`);
    }
  };
  try {
    await Promise.all(Array.from({ length: Math.min(3, roles.length) }, worker));
  } finally {
    button.disabled = false; button.textContent = "Analyze all paths";
    q("#all-gemini-opt-in").checked = false;
  }
});

q("#leaderboard-role").addEventListener("change", async (event) => { await loadLeaderboard(event.target.value); await runAnalysis({ role: event.target.value }); });
q("#leaderboard-min").addEventListener("input", (event) => { state.leaderboardMin = Math.max(1, Number(event.target.value) || 1); renderLeaderboard(); });
q("#leaderboard-sort").addEventListener("change", (event) => { state.leaderboardSort = event.target.value; renderLeaderboard(); });
q("#leaderboard-layout").addEventListener("change", (event) => { state.leaderboardLayout = event.target.value; renderLeaderboard(); });
q("#leaderboard-refresh").addEventListener("click", async () => { const role = q("#leaderboard-role").value; await loadLeaderboard(role, true); await runAnalysis({ role }); });
q("#leaderboard-export").addEventListener("click", () => exportLeaderboard("csv"));

async function runAnalysis(extra = {}) {
  if (!state.profile || !state.currentRole) return;
  const targetRole = extra.role || state.currentRole;
  const sameSavedTarget = targetRole === state.profile.currentPosition;
  const payload = { role: targetRole, location: extra.location || state.profile.location, company: extra.company ?? (sameSavedTarget ? state.profile.company : ""), profile: profileText(state.profile), level: extra.level || "beginner", hoursPerWeek: state.profile.hoursPerWeek, requirements: extra.requirements ?? (sameSavedTarget ? state.profile.roleNotes : ""), useAI: extra.useAI ?? extra.useGemini ?? false };
  const analysisKey = JSON.stringify({ role: payload.role, location: payload.location, company: payload.company, profile: payload.profile, level: payload.level, hoursPerWeek: payload.hoursPerWeek, requirements: payload.requirements });
  if (!extra.force && state.analysis && state.analysisKey === analysisKey) return state.analysis;
  state.analysisController?.abort();
  const controller = new AbortController(); state.analysisController = controller;
  const requestId = ++state.analysisRequest;
  const submit = q('#research-form button[type="submit"]');
  const submitLabel = submit?.querySelector("span");
  const oldLabel = submitLabel?.textContent;
  if (submit) submit.disabled = true;
  if (submitLabel) submitLabel.textContent = "Building map…";
  document.body.classList.add("is-analyzing");
  try {
    const response = await fetch("/api/analyze", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), signal: controller.signal });
    const data = await readJson(response);
    if (!response.ok) throw new Error(data.error || "Career maps need the Skill Bridge API host. Run python server.py or use the Vercel deployment.");
    if (requestId !== state.analysisRequest) return;
    state.analysis = data; state.analysisKey = analysisKey; state.currentRole = targetRole; renderAnalysis(data);
    return data;
  } catch (error) {
    if (error.name !== "AbortError" && requestId === state.analysisRequest) toast(error.message.includes("Failed to fetch") ? "Analysis service unavailable. Restart the local server and try again." : error.message);
  } finally {
    if (requestId === state.analysisRequest) {
      document.body.classList.remove("is-analyzing");
      if (submit) submit.disabled = false;
      if (submitLabel) submitLabel.textContent = oldLabel || "Build role map";
      if (payload.useGemini && q("#gemini-opt-in")) q("#gemini-opt-in").checked = false;
    }
  }
}

function renderAnalysis(data) {
  const strengths = data.skills.filter((item) => item.status === "strength").length;
  q("#stat-skills").textContent = data.skills.length;
  q("#stat-skills-caption").textContent = `${strengths} matched · ${Math.max(0, data.skills.length - strengths)} to learn`;
  q("#stat-strengths").textContent = strengths;
  q("#hero-milestone").textContent = data.plan[0]?.title || "No learning gaps found";
  q("#hero-milestone-sub").textContent = data.plan[0]?.task || "Review your profile against this role.";
  q("#first-move-title").textContent = data.plan[0]?.title || "Keep building your role skills";
  q("#first-move-copy").textContent = data.plan[0]?.task || "Review a project from your portfolio and record what you learned.";
  q("#map-title").textContent = data.role;
  q("#map-summary").textContent = data.company ? `Comparing your profile with ${data.company} and the ${data.role} requirements.` : `Comparing your experience with ${data.role} requirements.`;
  const modelLabel = data.aiMode === "gemini" ? "Gemini + local match" : data.aiMode === "rules" ? "Local match · AI unavailable" : "Local skill match";
  q("#map-source").textContent = `${data.source} · ${modelLabel}`;
  q("#readiness-number").textContent = `${data.readiness}%`;
  const ring = q("#gauge-ring"); ring.style.strokeDasharray = "270"; ring.style.strokeDashoffset = String(270 - 270 * data.readiness / 100);
  renderSources(data.sources || []); renderRoadmap(data.plan); renderSkills(data.skills); renderVideos(data.videos || [], data.videoMode); renderResources(data.resources || []); renderCourseRecommendations(data.courses || [], data.role);
  const completed = data.plan.filter((step) => state.profile.done?.includes(step.id || step.skill) || state.profile.done?.includes(step.skill)).length;
  setProgress(q("#sidebar-progress-bar"), data.plan.length ? Math.round(completed / data.plan.length * 100) : 0);
  q("#sidebar-progress-label").textContent = `${completed} of ${data.plan.length} milestones complete`;
  q("#roadmap-weeks").textContent = `${data.plan.length} steps · ${state.profile.hoursPerWeek || 5} hrs/week`;
  q("#library-priority").textContent = data.skills.find((item) => item.status === "gap")?.name || data.role;
  q("#library-priority-copy").textContent = `Courses, repositories, and videos for ${data.skills.find((item) => item.status === "gap")?.name || data.role}.`;
  q("#research-results").classList.remove("hidden");
  q("#research-result-title").textContent = `${data.company ? `${data.company} · ` : ""}${data.role} map is ready`;
  q("#research-result-subtitle").textContent = `${data.jobCount} job descriptions compared · ${strengths} of ${data.skills.length} skills found in your profile`;
  const tailored = data.courses?.some((course) => String(course.source || "").includes("guided"));
  q("#course-cover-copy").textContent = `Five course searches for ${data.role}${tailored ? " · search terms tailored with AI" : " · role-focused provider searches"}.`;
  const chips = q("#research-result-skills"); chips.replaceChildren();
  data.skills.slice(0, 9).forEach((skill) => { const chip = el("span", `result-chip ${skill.status}`, skill.name); chip.append(el("small", "", skill.status === "strength" ? " · have" : " · learn")); chips.append(chip); });
}

function renderSources(sources) {
  const wrap = q("#analysis-sources"); if (!wrap) return;
  wrap.replaceChildren();
  sources.forEach((source) => {
    const row = el("div", "source-row"), copy = el("div", "source-row-copy");
    copy.append(el("b", "", source.area), el("span", "", source.name), el("small", "", source.detail)); row.append(copy);
    if (source.url) { const link = el("a", "source-link", "Open source ↗"); link.href = safeUrl(source.url); link.target = "_blank"; link.rel = "noopener noreferrer"; row.append(link); }
    wrap.append(row);
  });
}

function renderCourseRecommendations(courses, role) {
  const grid = q("#course-recommendations"); if (!grid) return;
  grid.replaceChildren();
  if (!courses.length) { grid.append(el("div", "empty-library", "Course searches will appear after you build a role map.")); return; }
  courses.slice(0, 5).forEach((course, index) => {
    const theme = String(course.thumbnailTheme || role || "custom").toLowerCase().replace(/[^a-z0-9-]/g, "");
    const card = el("a", `course-card course-cover-${theme}`); card.href = safeUrl(course.url); card.target = "_blank"; card.rel = "noopener noreferrer";
    const topic = `${course.topic || ""} ${course.title || ""}`.toLowerCase();
    const artwork = /data|statistic|dashboard|visuali|excel|sql|tableau|power bi/.test(topic) ? "analysis"
      : /code|software|python|program|javascript|git|api|engineer/.test(topic) ? "code"
      : /ux|user|research|design|figma/.test(topic) ? "research"
      : /project|product|agile|manage|strategy/.test(topic) ? "roadmap"
      : ["analysis", "code", "research", "roadmap", "portfolio"][index % 5];
    const thumb = el("span", "course-card-thumb");
    const image = document.createElement("img"); image.src = `public/course-art/${artwork}.svg`; image.alt = `${course.topic || course.title} learning resource illustration`; image.loading = "lazy"; thumb.append(image);
    const body = el("span", "course-card-copy"); body.append(el("b", "", course.topic || course.title), el("span", "course-skill", course.title), el("small", "", course.description));
    const footer = el("span", "course-card-source"); footer.append(el("span", "course-provider", course.provider), el("small", "", course.source));
    card.append(thumb, body, footer); grid.append(card);
  });
}

function renderRoadmap(plan) {
  const list = q("#roadmap-list"); list.replaceChildren();
  plan.forEach((step, index) => {
    const doneKey = step.id || step.skill;
    const done = state.profile.done?.includes(doneKey) || state.profile.done?.includes(step.skill);
    const item = el("article", `roadmap-step ${done ? "complete" : index === 0 ? "current" : ""}`);
    const track = el("div", "step-track"); track.append(el("span", "step-node", done ? "✓" : String(index + 1).padStart(2, "0")));
    if (index < plan.length - 1) track.append(el("span", "step-connector"));
    const main = el("div", "step-main"); main.append(el("span", "step-time", `${step.week} · ${step.sessions || 1} sessions / week`)); main.append(el("h4", "", step.title)); addMore(main, step.description, "step-description", 145);
    if (step.source) main.append(sourceLink(step.source, "Skill source"));
    if (step.task) { main.append(el("b", "step-task-label", "PRACTICE")); addMore(main, step.task, "step-task", 135); }
    if (step.proof) { main.append(el("b", "step-task-label", "SAVE")); addMore(main, step.proof, "step-proof", 120); }
    if (step.resources?.length) {
      const links = el("div", "step-resource-links");
      step.resources.slice(0, 3).forEach((resource) => { const link = el("a", "step-resource-link", resource.provider); link.href = safeUrl(resource.url); link.title = resource.source || `${resource.provider} search link`; link.target = "_blank"; link.rel = "noopener noreferrer"; links.append(link); });
      main.append(links);
    }
    const footer = el("div", "step-footer"); footer.append(el("span", "step-skill-tag", step.skill));
    const complete = el("button", `step-done ${done ? "checked" : ""}`, done ? "Completed" : "Mark complete"); complete.type = "button";
    complete.addEventListener("click", () => { const values = new Set(state.profile.done || []); values.delete(step.skill); values.delete(doneKey); if (!done) values.add(doneKey); state.profile.done = [...values]; saveProfile(); renderProfile(); renderRoadmap(plan); toast(done ? "Milestone reopened." : "Milestone complete."); });
    footer.append(complete); main.append(footer); item.append(track, main); list.append(item);
  });
  const completed = plan.filter((step) => state.profile.done?.includes(step.id || step.skill) || state.profile.done?.includes(step.skill)).length;
  const progressCard = q(".sidebar-progress"), allFourDone = plan.length === 4 && completed === 4;
  const wasComplete = progressCard.classList.contains("is-complete");
  progressCard.classList.toggle("is-complete", allFourDone);
  progressCard.classList.toggle("completion-pulse", allFourDone && !wasComplete);
  if (!allFourDone) progressCard.classList.remove("completion-pulse");
  setProgress(q("#sidebar-progress-bar"), plan.length ? Math.round(completed / plan.length * 100) : 0);
  q("#sidebar-progress-label").textContent = allFourDone ? "All four milestones complete" : `${completed} of ${plan.length} milestones complete`;
  q("#sidebar-progress-sub").textContent = allFourDone ? "Your progress is saved. You finished the plan." : "Progress saves in this browser.";
}
function renderSkills(skills) {
  const wrap = q("#map-skills"); wrap.replaceChildren();
  skills.forEach((skill) => {
    const row = el("div", "map-skill-row"); const top = el("div", "map-skill-top");
    top.append(el("b", "", skill.name), el("span", `skill-state ${skill.status}`, skill.status === "strength" ? "HAVE" : "LEARN"));
    const foot = el("div", "skill-foot");
    addMore(foot, skill.reason || (skill.status === "strength" ? "Listed in your profile" : "Included in your learning plan"), "skill-explanation", 150);
    foot.append(sourceLink(skill.status === "strength" ? "Your browser profile" : skill.source, "Source", skill.status === "strength" ? "" : skill.sourceUrl || ""));
    row.append(top, foot); wrap.append(row);
  });
}
function renderVideos(videos, mode = "curated") {
  const unique = [...new Map(videos.filter((item) => item.videoId || item.playlistId || item.kind === "search").map((item) => [item.candidateId || item.videoId || item.playlistId, item])).values()];
  const strips = [q("#map-videos"), q("#library-videos")];
  q("#video-recommendation-copy").textContent = mode === "gemini" ? "Role-matched lessons and searches; thumbnails open directly on YouTube." : mode === "youtube-api" ? "Matched lessons and searches; thumbnails open directly on YouTube." : "Thumbnails open YouTube; select a title to preview a lesson here.";
  strips.forEach((wrap) => {
    wrap.replaceChildren();
    if (!unique.length) { wrap.append(el("div", "video-placeholder", "No lesson searches yet. Refresh this career map to try again.")); return; }
    unique.forEach((video) => wrap.append(videoCard(video)));
  });
}
function videoCard(video) {
  const card = el("article", `video-card ${video.kind === "search" ? "video-card-search" : ""}`);
  const thumb = el("a", "video-thumb video-thumb-link"); thumb.href = safeUrl(video.url); thumb.target = "_blank"; thumb.rel = "noopener noreferrer";
  thumb.setAttribute("aria-label", video.kind === "search" ? `Open YouTube search for ${video.skill} lessons` : `Open ${video.kind === "playlist" ? "playlist" : "video"}: ${video.title}`);
  if (video.kind === "search") {
    thumb.classList.add("video-thumb-search"); thumb.append(el("span", "search-thumb-label", "YOUTUBE SEARCH"), el("b", "search-thumb-skill", video.skill), el("span", "search-thumb-mark", "▶"));
  } else {
    const img = document.createElement("img"); img.src = safeUrl(video.thumbnail); img.alt = `Thumbnail for ${video.title}`; img.loading = "lazy"; img.onerror = () => { img.style.display = "none"; thumb.classList.add("thumb-fallback"); };
    const play = el("span", "play-button", "▶"); thumb.append(img, play, el("span", "thumb-duration", video.kind === "playlist" ? "PLAYLIST" : "VIDEO"));
  }
  const copy = el("button", "video-copy video-copy-action"); copy.type = "button"; copy.setAttribute("aria-label", video.kind === "search" ? `Open YouTube search for ${video.skill} lessons` : `Preview ${video.kind === "playlist" ? "playlist" : "video"}: ${video.title}`);
  copy.append(el("span", "video-skill", video.skills?.join(" · ") || video.skill || "RECOMMENDED"), el("b", "", video.title), el("small", "", video.channel || video.description || "YouTube lesson"), el("small", "video-source", video.kind === "search" ? "YouTube search · current results" : `Source · ${video.source === "youtube-api" ? "YouTube Data API" : "Curated YouTube recommendation"}`));
  copy.addEventListener("click", () => video.kind === "search" ? window.open(safeUrl(video.url), "_blank", "noopener,noreferrer") : openVideo(video));
  card.append(thumb, copy); return card;
}
function openVideo(video) {
  q("#dialog-title").textContent = video.title;
  q("#dialog-channel").textContent = video.channel || video.description || "Recommended video";
  q("#dialog-skill").textContent = video.skill ? `FOR YOUR ${video.skill.toUpperCase()} PATH` : "RECOMMENDED FOR YOUR PATH";
  q("#dialog-watch-link").href = safeUrl(video.url);
  q("#video-frame").src = video.kind === "playlist"
    ? `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(video.playlistId)}&autoplay=1&rel=0`
    : `https://www.youtube-nocookie.com/embed/${encodeURIComponent(video.videoId)}?autoplay=1&rel=0`;
  q("#video-dialog").showModal();
}
q("#video-dialog").addEventListener("close", () => { q("#video-frame").src = "about:blank"; });
function renderResources(resources) {
  const containers = [q("#learning-resources")];
  containers.forEach((wrap) => {
    wrap.replaceChildren();
    resources.forEach((resource) => {
      const link = el("a", "resource-card"); link.href = safeUrl(resource.url); link.target = "_blank"; link.rel = "noopener noreferrer";
      link.append(el("span", "resource-icon", resource.icon || "↗")); const copy = el("span", "resource-copy"); copy.append(el("b", "", resource.title), el("small", "", resource.description), el("small", "resource-source", `Source · ${resource.source || resource.provider}`));
      link.append(copy, el("span", "resource-arrow", "↗")); wrap.append(link);
    });
  });
}

q("#research-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const role = cleanText(q("#research-role").value), company = cleanText(q("#research-company").value), location = cleanText(q("#research-location").value) || state.profile.location;
  state.currentRole = role;
  state.profile.company = company; state.profile.currentPosition = role; state.profile.roleUrl = cleanText(q("#research-url").value); state.profile.roleNotes = cleanText(q("#role-description").value);
  if (!state.profile.roles.includes(role)) state.profile.roles.unshift(role);
  saveProfile(); renderProfile(); await loadLeaderboard(role, true); await runAnalysis({ role, company, location, requirements: state.profile.roleNotes, useAI: q("#gemini-opt-in").checked, force: true });
  q(".role-research-details").open = true; q("#research-results").scrollIntoView({ behavior: "smooth", block: "nearest" });
});

function assistantMessage(text, who = "assistant") {
  const message = el("div", `assistant-message ${who}`, text);
  q("#assistant-messages").append(message); q("#assistant-messages").scrollTop = q("#assistant-messages").scrollHeight;
  const messages = qa(".assistant-message", q("#assistant-messages"));
  while (messages.length > 30) messages.shift().remove();
  saveGuideChat();
  return message;
}
function saveGuideChat() {
  try {
    const messages = qa(".assistant-message", q("#assistant-messages")).slice(-30).map((node) => ({
      text: node.textContent.slice(0, 1200), who: node.classList.contains("user") ? "user" : "assistant",
    }));
    localStorage.setItem(GUIDE_CHAT_KEY, JSON.stringify(messages));
  } catch { /* Keep chat usable when browser storage is full or disabled. */ }
}
function restoreGuideChat() {
  try {
    const saved = JSON.parse(localStorage.getItem(GUIDE_CHAT_KEY) || "[]");
    if (!Array.isArray(saved) || !saved.length) return;
    const box = q("#assistant-messages"); box.replaceChildren();
    saved.slice(-30).forEach((item) => {
      if (item && typeof item.text === "string" && ["user", "assistant"].includes(item.who))
        box.append(el("div", `assistant-message ${item.who === "user" ? "user" : ""}`, item.text.slice(0, 1200)));
    });
    box.scrollTop = box.scrollHeight;
  } catch { /* Ignore malformed local history. */ }
}
restoreGuideChat();
async function askAssistant(message, toolResult = null) {
  const data = state.analysis?.role === state.currentRole ? state.analysis : state.pathAnalyses[state.currentRole];
  const learningContext = { profileSkills: [...(state.profile?.skills || []), state.profile?.moreSkills || ""].filter(Boolean).slice(0, 30), matchedSkills: (data?.skills || []).filter((item) => item.status === "strength").map((item) => item.name).slice(0, 20), skillsToBuild: (data?.skills || []).filter((item) => item.status !== "strength").map((item) => item.name).slice(0, 20), tools: data?.tools || [], roadmap: (data?.plan || []).map((item) => item.title), studyHoursThisWeek: Math.round(getStudySecondsThisWeek() / 60) / 60, weeklyStudyTarget: state.profile?.hoursPerWeek || 5 };
  const response = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message, pageState: { selectedTitle: state.currentRole, titles: state.profile?.roles || [], learningContext, toolResult } }) });
  const result = await readJson(response);
  if (!response.ok) throw new Error(result.error || "The Skill Bridge API host is unavailable.");
  return result;
}
function exportLeaderboard(format) {
  const role = q("#leaderboard-role").value; const board = state.leaderboards[leaderboardProfileKey(role)];
  if (!board) { toast("Load a leaderboard before exporting."); return { ok: false, reason: "No leaderboard loaded" }; }
  const rows = (board.skills || []).filter((item) => item.count >= state.leaderboardMin);
  const csv = ["job_title,skill,count,listings,percent", ...rows.map((item) => [role, item.skill, item.count, board.jobCount, item.percent].map((part) => `"${String(part).replaceAll('"', '""')}"`).join(","))].join("\n");
  const content = format === "json" ? JSON.stringify({ ...board, skills: rows }, null, 2) : csv;
  const blob = new Blob([content], { type: format === "json" ? "application/json" : "text/csv" }); const link = document.createElement("a");
  link.href = URL.createObjectURL(blob); link.download = `skill-bridge-${role.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.${format}`; link.click(); URL.revokeObjectURL(link.href);
  return { ok: true, title: role, count: rows.length, format };
}
async function executeAssistantAction(name, args = {}) {
  const title = args.title || "";
  if (name === "switchJobTitle") {
    if (!(state.profile.roles || []).includes(title)) return { ok: false, reason: "That title is not in the profile." };
    state.currentRole = title; await loadLeaderboard(title); runAnalysis(); return { ok: true, selected: title };
  }
  if (name === "addJobTitle") {
    const existing = state.profile.roles.find((item) => item.toLowerCase() === title.toLowerCase());
    if (existing) { state.currentRole = existing; await loadLeaderboard(existing); return { ok: true, selected: existing, message: "Title already existed." }; }
    if (state.profile.roles.length >= 12) return { ok: false, reason: "The profile limit is 12 career titles." };
    state.profile.roles.unshift(title); state.currentRole = title; saveProfile(); renderProfile(); await loadLeaderboard(title, true); runAnalysis();
    return { ok: true, added: title, source: state.leaderboards[leaderboardProfileKey(title)]?.source || "sample fallback" };
  }
  if (name === "refreshData") {
    if (!(state.profile.roles || []).includes(title)) return { ok: false, reason: "Add that title to your profile first." };
    await loadLeaderboard(title, true); return { ok: Boolean(state.leaderboards[leaderboardProfileKey(title)]), refreshed: title };
  }
  if (name === "filterSkills") { state.leaderboardMin = Math.max(1, Number(args.minCount) || 1); q("#leaderboard-min").value = state.leaderboardMin; renderLeaderboard(); return { ok: true, minCount: state.leaderboardMin }; }
  if (name === "sortLeaderboard") { state.leaderboardSort = args.order; q("#leaderboard-sort").value = args.order; renderLeaderboard(); return { ok: true, order: args.order }; }
  if (name === "highlightSkill") { state.highlightedSkill = args.skillName; renderLeaderboard(); const item = qa(".leaderboard-item").find((node) => node.querySelector("h3")?.textContent.toLowerCase() === args.skillName.toLowerCase()); item?.scrollIntoView({ behavior: "smooth", block: "center" }); return { ok: Boolean(item), skill: args.skillName }; }
  if (name === "exportData") return exportLeaderboard(args.format);
  if (name === "changeLayout") { state.leaderboardLayout = args.layout; q("#leaderboard-layout").value = args.layout; renderLeaderboard(); return { ok: true, layout: args.layout }; }
  return { ok: true, message: "No page action needed." };
}
q("#assistant-toggle").addEventListener("click", () => { q("#assistant-panel").classList.toggle("hidden"); if (!q("#assistant-panel").classList.contains("hidden")) q("#assistant-input").focus(); });
q("#assistant-close").addEventListener("click", () => q("#assistant-panel").classList.add("hidden"));
q("#assistant-clear").addEventListener("click", () => {
  q("#assistant-messages").replaceChildren(el("div", "assistant-message", "Hi! I’m The Guide. Ask about your skills, learning plan, or how to use this page."));
  saveGuideChat(); toast("Guide chat cleared from this browser.");
});
q("#assistant-form").addEventListener("submit", async (event) => {
  event.preventDefault(); const input = q("#assistant-input"); const message = cleanText(input.value); if (!message) return;
  assistantMessage(message, "user"); input.value = ""; const pending = assistantMessage("Thinking…");
  try {
    const result = await askAssistant(message);
    if (result.type === "action") {
      const outcome = await executeAssistantAction(result.name, result.args);
      pending.textContent = `${result.content || "Page action complete."} ${outcome.ok ? "Done." : (outcome.reason || "I couldn't complete that change.")}`;
    } else pending.textContent = result.content || "I couldn’t find a supported action for that request.";
    saveGuideChat();
  } catch (error) { pending.textContent = error.message || "The assistant is unavailable. Try again."; saveGuideChat(); }
});

function renderEditProfile() {
  const profile = state.profile;
  q("#edit-name").value = profile.name || ""; q("#edit-stage").value = profile.stage || "Student"; q("#edit-location").value = profile.location || "India"; q("#edit-hours").value = String(profile.hoursPerWeek || 5); q("#edit-more-skills").value = profile.moreSkills || "";
  paintAvatar(q("#profile-large-avatar"), profile.avatar || "sprout", profile.avatarPhoto);
  updateProfilePhotoControls();
  renderAvatarChoices("#edit-avatar-options", profile.avatarPhoto ? "" : (profile.avatar || "sprout"));
  renderChoices(q("#edit-role-options"), [...new Set([...ROLES, ...(profile.roles || [])])], profile.roles || [], "role");
  renderSkillChoices(q("#edit-skill-options"), profile.skills || []);
}
q("#profile-photo-file").addEventListener("change", async (event) => {
  const file = event.target.files?.[0]; if (!file) return;
  try {
    const photo = await resizeProfilePhoto(file);
    state.profile.avatarPhoto = photo; const stored = saveProfile(); renderProfile(); renderEditProfile();
    toast(stored ? "Your professional photo was saved in this browser." : "Photo applied for this visit; browser storage is full.");
  } catch (error) { toast(error.message || "Could not save that photo."); }
  finally { event.target.value = ""; }
});
q("#remove-profile-photo").addEventListener("click", () => {
  state.profile.avatarPhoto = ""; saveProfile(); renderProfile(); renderEditProfile(); toast("Profile photo removed.");
});
q("#profile-export").addEventListener("click", () => {
  const backup = {
    product: "Skill Bridge", formatVersion: 1, exportedAt: new Date().toISOString(),
    profile: state.profile, study: state.study, roleMaps: state.pathAnalyses,
    guideChat: (() => { try { return JSON.parse(localStorage.getItem(GUIDE_CHAT_KEY) || "[]"); } catch { return []; } })(),
  };
  const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" }));
  const link = document.createElement("a"); link.href = url; link.download = "skill-bridge-data.json"; link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("Your Skill Bridge data was downloaded to this device.");
});
q("#edit-add-role").addEventListener("click", () => addChoice("#edit-role-options", "#edit-custom-role", ROLES, "role"));
q("#edit-profile-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const roles = selectedFrom(q("#edit-role-options")); if (!roles.length) { toast("Keep at least one career path in your profile."); return; }
  const hours = Number(q("#edit-hours").value); if (!Number.isInteger(hours) || hours < 1 || hours > 80) { toast("Enter a weekly target from 1 to 80 whole hours."); q("#edit-hours").focus(); return; }
  Object.assign(state.profile, { name: cleanText(q("#edit-name").value) || "Learner", stage: q("#edit-stage").value, location: cleanText(q("#edit-location").value) || "India", hoursPerWeek: hours, roles, skills: selectedSkills(q("#edit-skill-options")), moreSkills: cleanText(q("#edit-more-skills").value), avatar: state.selectedAvatar });
  state.pathAnalyses = {};
  if (!roles.includes(state.currentRole)) state.currentRole = roles[0];
  saveProfile(); renderProfile(); await runAnalysis(); toast("Your profile has been updated."); navigate("profile");
});

function restore() {
  renderWelcome();
  showScreen("welcome");
}
restore();
