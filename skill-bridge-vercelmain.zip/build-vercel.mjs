import { cpSync, existsSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const output = join(root, "dist");
mkdirSync(output, { recursive: true });

for (const file of ["index.html", "app.js", "styles.css", "guide-wizard.svg", "PROJECT_CONTEXT.md"]) {
  cpSync(join(root, file), join(output, file));
}

for (const directory of ["public", "data"]) {
  const source = join(root, directory);
  if (existsSync(source)) cpSync(source, join(output, directory), { recursive: true });
}

console.log("Prepared Skill Bridge static frontend in dist/.");
