"""Small, quota-conscious Gemini JSON client shared by Skill Bridge APIs."""
import json
import os
import threading
import urllib.error
import urllib.parse
import urllib.request


# Independent role requests can be concurrent in the UI; keep provider traffic bounded.
_CALL_SLOTS = threading.BoundedSemaphore(2)
DEFAULT_MODEL = "gemini-3.5-flash-lite"


def generate_json(prompt, schema, *, max_output_tokens=1200, temperature=0.2, timeout=8):
    """Return one schema-constrained JSON response, or None for any provider failure.

    No automatic retries: retrying quota errors makes overload worse. Callers keep
    their local deterministic fallback when the key is absent, busy, or rate limited.
    """
    key = os.environ.get("GEMINI_API_KEY")
    if not key or not _CALL_SLOTS.acquire(timeout=1.5):
        return None
    try:
        model = os.environ.get("GEMINI_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL
        body = json.dumps({"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {
            "responseMimeType": "application/json", "responseSchema": schema,
            "maxOutputTokens": max(64, min(2048, int(max_output_tokens))),
            "temperature": max(0, min(1, float(temperature))),
        }}).encode("utf-8")
        request = urllib.request.Request(
            f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(model, safe='')}:generateContent",
            data=body, headers={"Content-Type": "application/json", "x-goog-api-key": key}, method="POST")
        with urllib.request.urlopen(request, timeout=timeout) as response:
            result = json.loads(response.read().decode("utf-8"))
        text = result["candidates"][0]["content"]["parts"][0]["text"].strip()
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            # Some Gemini models occasionally wrap schema-constrained JSON in a
            # short preamble. Recover the single JSON object without accepting
            # arbitrary trailing content.
            start = text.find("{")
            end = text.rfind("}")
            if start < 0 or end <= start:
                return None
            parsed = json.loads(text[start:end + 1])
        return parsed if isinstance(parsed, dict) else None
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError,
            KeyError, IndexError, TypeError, OSError):
        return None
    finally:
        _CALL_SLOTS.release()
