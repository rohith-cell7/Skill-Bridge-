"""Regenerate the privacy-safe, offline sample title leaderboards."""
import json
from pathlib import Path
import time

import skill_engine

TITLES = [
    "Data Analyst", "Data Scientist", "Data Engineer", "Software Engineer",
    "UX Designer", "Product Manager", "Project Manager", "Cybersecurity Analyst",
    "Business Analyst", "Digital Marketer",
]
boards = {}
for role in TITLES:
    jobs = [{"title": title, "description": description} for title, description in skill_engine._sample_for_role(role)]
    counts = {}
    for job in jobs:
        for skill in set(skill_engine._find_skills(job["title"] + " " + job["description"])):
            counts[skill] = counts.get(skill, 0) + 1
    skills = [{"skill": skill, "count": count, "percent": round(count * 100 / max(1, len(jobs)))} for skill, count in counts.items()]
    skills.sort(key=lambda item: (-item["count"], item["skill"].casefold()))
    boards[role] = {"role": role, "jobCount": len(jobs), "source": "offline demo sample", "skills": skills[:20], "updatedAt": int(time.time())}

Path("data/skills_leaderboard.json").write_text(json.dumps(boards, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Generated offline sample boards for {len(boards)} job titles.")
