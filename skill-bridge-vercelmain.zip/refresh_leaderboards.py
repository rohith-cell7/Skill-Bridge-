"""Refresh cached public job-title leaderboards using Adzuna's API."""
import argparse
import json
import os
import time
from pathlib import Path

from skill_engine import skills_leaderboard


DATA_FILE = Path(__file__).resolve().parent / "data" / "skills_leaderboard.json"
DEFAULT_TITLES = [
    "Data Analyst", "Data Scientist", "Data Engineer", "Software Engineer",
    "UX Designer", "Product Manager", "Project Manager", "Cybersecurity Analyst",
    "Business Analyst", "Digital Marketer",
]


def configured_titles():
    raw = os.environ.get("JOB_TITLES", "")
    titles = [part.strip()[:100] for part in raw.split(",") if part.strip()]
    return list(dict.fromkeys(titles)) or DEFAULT_TITLES


def refresh(titles):
    boards = {}
    if DATA_FILE.is_file():
        try:
            boards = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            boards = {}
    for index, title in enumerate(titles):
        if not title or len(title) > 100:
            raise ValueError("Job titles must be between 1 and 100 characters.")
        board = skills_leaderboard({"role": title, "location": "India"})
        if os.environ.get("ADZUNA_APP_ID") and os.environ.get("ADZUNA_APP_KEY") and board["source"].startswith("demo sample"):
            raise RuntimeError(f"No live job results returned for {title}; saved data was left unchanged.")
        boards[title] = board
        print(f"Updated {title}: {board['jobCount']} listings ({board['source']}).")
        if index < len(titles) - 1:
            time.sleep(2)
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = DATA_FILE.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(boards, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(DATA_FILE)
    return len(titles)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job-title", help="Refresh one title instead of the configured list.")
    args = parser.parse_args()
    titles = [args.job_title.strip()] if args.job_title else configured_titles()
    if len(titles) > 30:
        parser.error("Set at most 30 job titles per scheduled run.")
    refresh(titles)


if __name__ == "__main__":
    main()
