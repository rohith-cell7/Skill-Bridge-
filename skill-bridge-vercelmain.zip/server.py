"""Zero-dependency local static/API server for Skill Bridge."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent

def load_local_env():
    """Load simple KEY=value entries for local use; never overwrite shell vars."""
    env_file = ROOT / ".env"
    if not env_file.is_file():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        value = line.strip()
        if not value or value.startswith("#"):
            continue
        if value.startswith("export "):
            value = value[7:].lstrip()
        key, separator, content = value.partition("=")
        if separator and key.strip() and key.strip() not in os.environ:
            content = content.strip().strip("\"'")
            os.environ[key.strip()] = content


load_local_env()

from skill_engine import analyze, skills_leaderboard
from assistant_engine import answer as assistant_answer


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "OPTIONS,POST")
        self.end_headers()

    def do_POST(self):
        endpoint = urlparse(self.path).path
        if endpoint not in {"/api/analyze", "/api/leaderboard", "/api/assistant"}:
            self.send_error(404)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size > 26000:
                raise ValueError("Please keep your profile and role notes under 26 KB.")
            data = json.loads(self.rfile.read(size) or b"{}")
            if not isinstance(data, dict):
                raise ValueError("Send a JSON object with your request.")
            if endpoint == "/api/analyze":
                result = analyze(data)
            elif endpoint == "/api/leaderboard":
                result = skills_leaderboard(data)
            else:
                result = assistant_answer(data.get("message", ""), data.get("pageState", {}))
            self._json(200, result)
        except (ValueError, json.JSONDecodeError) as exc:
            self._json(400, {"error": str(exc)})
        except Exception:
            self._json(502, {"error": "Analysis could not finish. Please try again in a moment."})

    def _json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    print(f"Skill Bridge running at http://localhost:{port}")
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
